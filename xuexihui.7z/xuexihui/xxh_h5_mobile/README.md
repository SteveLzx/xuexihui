# xxh_h5_mobile

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).


#### Missing semicolon semi
`少了分号`

#### Unexpected use of file extension "js" for "./assets/js/rem.js"
`省略掉.js`

#### Unexpected use of file extension "ts" for "./assets/js/rem.ts"
`省略掉.ts`

#### A space is required after
`需要空格`

#### Strings must use singlequote 
`string类型的需要使用单引号`

#### More than 2 blank lines not allowed
`不允许超过两个空行`

#### Use object destructuring
`使用对象解构`

#### Unexpected space before function parentheses
`函数括号前不要有括号`

#### Expected space(s) after "default"
`default后面还有空格`

#### Expected property shorthand
`bad`
{
  data: data
}
`good`
{
    data
}

#### 'match' is never reassigned. Use 'const' instead
`match没有再分配，使用const声明`

#### Unexpected string concatenation
`使用${}`


#### Property 'picValue' has no initializer and is not definitely assigned in the constructor.
`picValue!: `
