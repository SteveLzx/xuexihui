declare const window: Window & { xxh: any; webkit: any };
// 移动终端浏览器版本信息
const { userAgent } = navigator;
export const versions = {
  trident: userAgent.indexOf('Trident') > -1, // IE内核
  presto: userAgent.indexOf('Presto') > -1, // opera内核
  webKit: userAgent.indexOf('AppleWebKit') > -1, // 苹果、谷歌内核
  gecko: userAgent.indexOf('Gecko') > -1 && userAgent.indexOf('KHTML') === -1, // 火狐内核
  mobile: !!userAgent.match(/AppleWebKit.*Mobile.*/) || !!userAgent.match(/AppleWebKit/), // 是否为移动终端
  ios: !!userAgent.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/), // ios终端
  android: userAgent.indexOf('Android') > -1 || userAgent.indexOf('Linux') > -1, // android终端或者uc浏览器
  iPhone: userAgent.indexOf('iPhone') > -1 || userAgent.indexOf('Mac') > -1, // 是否为iPhone或者QQHD浏览器
  iPad: userAgent.indexOf('iPad') > -1, // 是否iPad
  webApp: userAgent.indexOf('Safari') === -1, // 是否web应该程序
  wechat: !!userAgent.match(/MicroMessenger/i) // 是否微信
};

// 获取url的query值
export const getQueryString = (name: string) => {
  const match = RegExp(`[?&]${name}=([^&]*)`).exec(window.location.href);
  if (match) {
    return decodeURIComponent(match[1].replace(/\+/g, ' '));
  }
  return match;
};

// 与app 交互方法
export const jsCallAppParam = (type: number, param: object) => {
  if (window.xxh) {
    // Android
    window.xxh.jsCallAppParam(JSON.stringify({
      type,
      param
    }));
  } else if (window.webkit) {
    // IOS
    window.webkit.messageHandlers.jsCallAppParam.postMessage(JSON.stringify({
      type,
      param
    }));
  }
};

// 年月日过滤
export const filterTimeToDate = (arg?: Date | string) => {
  let date = arg;
  if (!date) return {};
  if (typeof date === 'string' && date.indexOf('-')) {
    date = date.replace(/-/g, '/');
  }
  const filterTime = new Date(date);
  const arr = [
    filterTime.getMonth() + 1,
    filterTime.getDate(),
    filterTime.getHours(),
    filterTime.getMinutes(),
    filterTime.getSeconds()
  ];
  arr.forEach((val: any, i: number) => {
    let item = val;
    if (item < 10) {
      item = `0${item}`;
    }
    arr[i] = item;
  });
  arr.unshift(filterTime.getFullYear());
  return {
    monthDay: `${arr[1]}月${arr[2]}日`,
    date: `${arr[0]}/${arr[1]}/${arr[2]}`,
    date2: `${arr[0]}-${arr[1]}-${arr[2]}`,
    time: `${arr[3]}:${arr[4]}:${arr[5]}`,
    time2: `${arr[3]}:${arr[4]}`,
    dateTime: `${arr[0]}/${arr[1]}/${arr[2]} ${arr[3]}:${arr[4]}:${arr[5]}`,
    dateTime1: `${arr[0]}-${arr[1]}-${arr[2]} ${arr[3]}:${arr[4]}`,
    dateTimeList: [arr[0], arr[1], arr[2], arr[3], arr[4], arr[5]]
  };
};

// 计算两个日期中间的日期
export const getAllDate = (start: Date | string, end: Date | string) => {
  let startTime: any = new Date(start);
  const endTime = new Date(end);
  const dataArr = [];
  while (endTime >= startTime) {
    startTime = new Date(startTime);
    const year = startTime.getFullYear();
    const month = startTime.getMonth() + 1;
    const day = startTime.getDate();
    const week = startTime.getDay();
    const weeks = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];

    const date = {
      text: `${year}年${month < 10 ? `0${month}` : month}月${day < 10 ? `0${day}` : day}日 ${weeks[week]}`,
      value: `${year}-${month < 10 ? `0${month}` : month}-${day < 10 ? `0${day}` : day}`
    };
    dataArr.push(date);
    startTime = new Date(date.value).getTime() + (24 * 60 * 60 * 1000);
  }
  return dataArr;
};

// 默认头像显示规则
export const getHeadPortrait = (text: string) => {
  let newText = '';
  // 中文：显示倒叙两个文字
  // 英文/数字/字符： 显示正序两个字母/数字/字符
  // 中文+英文/数字/字符： 显示倒叙两个文字/字母/字符
  const han = /^[\u4e00-\u9fa5]+$/;
  const en = /^[a-zA-Z0-9]+$/;
  if (han.test(text)) {
    newText = text.substring(text.length - 2);
  } else if (en.test(text)) {
    newText = text.substring(0, 2);
  } else {
    newText = text.substring(text.length - 2);
  }
  return newText;
};

export const countdown = (data: string) => {
  const now = new Date().getTime();
  const date = data.replace(/-/g, '/');
  const begin = new Date(date).getTime();
  const count = (begin - now) / 1000;
  return Math.ceil(count);
};

let Domain = 'http://xxh.maipingba.com';
let ImgDomain = 'https://xxh-prod-1254038939.cos.ap-guangzhou.myqcloud.com';
const hostName = window.location.hostname;
if (/(88ba|192.168|localhost)/i.test(hostName)) { // 测试环境 xxh.88ba.com
  Domain = 'http://xxh.maipingba.com';
  ImgDomain = 'https://xxh-test-1254038939.cos.ap-guangzhou.myqcloud.com';
} else if (/wanpingshidai/i.test(hostName)) { // beta环境 h5.wanpingshidai.com
  Domain = 'http://api.wanpingshidai.com';
} else if (/xuexihui/i.test(hostName)) { // 正式环境 h5.xuexihui.com
  Domain = 'https://api.xuexihui.com';
}
export const domain = Domain;
export const imgDomain = ImgDomain;
