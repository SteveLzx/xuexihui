import wx from 'weixin-js-sdk';
import { versions } from '@/assets/js/common';
import store from '@/store';
// 微信config
export const wxConfig = (link: string) => {
  const linkUrl = window.location.origin + link;
  console.log(store.state.wxCommon.wxConfigData);
  wx.config({
    debug: false,
    ...store.state.wxCommon.wxConfigData,
    jsApiList: ['updateAppMessageShareData', 'updateTimelineShareData']
  });
  wx.ready(() => {
    // 分享到朋友圈"
    wx.onMenuShareTimeline({
      title: '名片袋',
      link: linkUrl,
      desc: linkUrl,
      imgUrl: 'https://api.wanpinghui.com/static/images/wanpinghuilogo.png',
      success: () => {
        console.log('分享到朋友圈成功');
      },
      cancel: () => {
        console.log('分享到朋友圈失败');
      }
    });
    // 分享给朋友
    wx.onMenuShareAppMessage({
      title: '名片袋',
      desc: '描述',
      link: linkUrl,
      imgUrl: 'https://api.wanpinghui.com/static/images/wanpinghuilogo.png',
      success: () => {
        console.log('分享到朋友成功');
      },
      cancel: () => {
        console.log('分享到朋友失败');
      }
    });
  });
};
// 微信支付
let WeixinJSBridge: any;
const onBridgeReady = () => {
  WeixinJSBridge.invoke('getBrandWCPayRequest', {}, (res: any) => {
    if (res.err_msg === 'get_brand_wcpay_request:ok') {
      // 成功之后重新请求用户信息接口
    }
  });
};
export const payPay = () => {
  if (!versions.wechat) return;
  if (typeof WeixinJSBridge === 'undefined') {
    if (document.addEventListener) {
      document.addEventListener('WeixinJSBridgeReady', onBridgeReady, false);
    }
  } else {
    onBridgeReady();
  }
};
