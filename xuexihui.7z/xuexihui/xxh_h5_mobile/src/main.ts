import Vue from 'vue';
import { versions } from '@/assets/js/common';
import LazyLoad from '@/plugins/LazyLoad';
import Loading from '@/components/common/Loading';
import Toast from '@/components/common/Toast';
import Vconsole from 'vconsole';
import axios from './plugins/axios';
import router from './router';
import store from './store';
import './assets/js/rem';
import App from './App.vue';
import './components/directive';

Vue.use(LazyLoad, {
  error: 'erro',
  loading: 'loading',
  toast: 'toast'
});
Vue.config.productionTip = false;

Vue.prototype.versions = versions; // 判断各设备环境

Vue.prototype.$bus = new Vue(); // 兄弟组件传值

Vue.prototype.$loading = Loading; // loading

Vue.prototype.$xxhToast = Toast; // toast

Vue.prototype.$http = axios; // 请求

if (/(88ba|192|localhost)/i.test(window.location.hostname)) {
  const vConsole = new Vconsole(); // 本地和测试环境添加手机端控制台
}

new Vue({
  router,
  store,
  render: (h) => h(App)
}).$mount('#app');
