declare module '*.vue' {
  import Vue from 'vue';

  export default Vue;
}

declare module 'weixin-js-sdk';
declare module 'vuedraggable';
