import Vue from 'vue';
import VueRouter, { Route } from 'vue-router';
import { getQueryString, versions } from '@/assets/js/common';
import routes from '@/router/routes';
import axios from '@/plugins/axios';
import { wxConfig } from '@/assets/js/wxCommon';
import store from '@/store/index';

Vue.use(VueRouter);

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
});

let redirectUrl = window.location.href;
// 名片袋
const appId = 'wx9f3908a2946289bb';
window.localStorage.setItem('appId', appId);
router.beforeEach((to: Route, from: Route, next: Function) => {
  const { path, fullPath } = to;
  // 微信配置
  if (versions.wechat) {
    if (store.state.wxCommon.wxConfigData && store.state.wxCommon.wxConfigData.sign) {
      wxConfig(fullPath);
    } else {
      axios.post('user/wx/config', {
        url: encodeURI(window.location.href.split('#')[0])
      }).then((res) => {
        store.commit('wxCommon/setWxConfigData', res);
        wxConfig(fullPath);
      });
    }
  }
  // 已登录过
  if (window.localStorage.token) {
    if (path === '/login') { // 打开的是登录页面直接跳转默认页
      next('/', { replace: true });
      return;
    }
    const { blackList } = to.meta;
    if (window.localStorage.userRole) {
      if (blackList && blackList.includes('admin')) { // 用户角色无权限访问该页面
        next('/', { replace: true });
        return;
      }
    } else {
      // 请求后台信息
    }
    next();
    return;
  }
  // 无需登录白名单
  if (!to.meta.requireAuth) {
    next();
    return;
  }
  // 未登录过的微信环境
  if (versions.wechat) {
    const code = getQueryString('code');
    if (!code) { // 无code去重定向获取授权取code
      redirectUrl = encodeURIComponent(redirectUrl);
      window.location.href = `https://open.weixin.qq.com/connect/oauth2/authorize?appid=${appId}&redirect_uri=${redirectUrl}&response_type=code&scope=snsapi_userinfo&state=123#wechat_redirect`;
      return;
    }
    axios.post('user/wxlogin', { code }).then((res: object | any) => {
      const { token, openId } = res;
      if (token) { // 已绑定微信的用户
        window.localStorage.setItem('openId', openId);
        window.localStorage.setItem('token_app', token);
        // 获取已绑定过用户的信息
        axios.get('user/getUserInfo').then((data) => {
          localStorage.setItem('userInfoData', JSON.stringify(data));
          next();
        });
      } else {
        next({ name: 'Login' });
        return;
      }
      next();
    });
  }
  next();
});


export default router;
