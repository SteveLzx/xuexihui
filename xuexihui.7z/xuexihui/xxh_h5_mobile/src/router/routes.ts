// 路由列表
// requireAuth 是否需要登录
// blackList 角色黑名单 角色在此列表内则无法访问该页面
// keepAlive 页面是否需要缓存
const routes = [
  {
    path: '/',
    name: 'Home',
    component: () => import('../views/Home.vue'),
    meta: {
      requireAuth: false
    }
  },
  {
    path: '/about',
    name: 'About',
    component: () => import('../views/About.vue'),
    meta: {
      requireAuth: false,
      blackList: ['admin']
    }
  },
  {
    path: '/login',
    name: 'Login',
    component: () => import('../views/login/Login.vue'),
    meta: {
      requireAuth: false
    }
  },
  // 发起主题会议
  {
    path: '/createTheme',
    name: 'CreateTheme',
    component: () => import('../views/createTheme/CreateTheme.vue'),
    meta: {
      requireAuth: false,
      keepAlive: true
    }
  },
  // 我的学习会列表
  {
    path: '/myStudyMeeting',
    name: 'MyStudyMeeting',
    component: () => import('../views/myStudyMeeting/MyStudyMeeting.vue'),
    meta: {
      requireAuth: false
    }
  },
  // 新建学习会
  {
    path: '/addStudyMeeting',
    name: 'AddStudyMeeting',
    component: () => import('../views/addStudyMeeting/AddStudyMeeting.vue'),
    meta: {
      requireAuth: false,
      keepAlive: true
    }
  },
  // 设置文稿
  {
    path: '/editDraft',
    name: 'EditDraft',
    component: () => import('../views/editDraft/EditDraft.vue'),
    meta: {
      requireAuth: false
    }
  },
  // 编辑个人资料
  {
    path: '/editProfile',
    name: 'EditProfile',
    component: () => import('../views/editProfile/EditProfile.vue'),
    meta: {
      requireAuth: false
    }
  },
  // 设置议程
  {
    path: '/settingMeeting',
    name: 'SettingMeeting',
    component: () => import('../views/settingMeeting/SettingMeeting.vue'),
    meta: {
      requireAuth: false,
      keepAlive: true
    }
  },
  // 设置性别
  {
    path: '/genderSetting',
    name: 'GenderSetting',
    component: () => import('../views/editProfile/GenderSetting.vue'),
    meta: {
      requireAuth: false
    }
  },
  // 设置名字
  {
    path: '/nameSetting',
    name: 'NameSetting',
    component: () => import('../views/editProfile/NameSetting.vue'),
    meta: {
      requireAuth: false
    }
  },
  // 设置演讲人
  {
    path: '/settingSpeaker',
    name: 'SettingSpeaker',
    component: () => import('../views/settingSpeaker/SettingSpeaker.vue'),
    meta: {
      requireAuth: false
    }
  },
  // 用户协议
  {
    path: '/userAgreement',
    name: 'userAgreement',
    component: () => import('../views/agreement/UserAgreement.vue'),
    meta: {
      requireAuth: false
    }
  },
  // 加入学习会
  {
    path: '/joinLearning',
    name: 'joinLearning',
    component: () => import('../views/joinLearning/JoinLearning.vue')
  },
  // 我的会议列表
  {
    path: '/myMeeting',
    name: 'myMeeting',
    component: () => import('../views/myMeeting/MyMeeting.vue'),
    meta: {
      keepAlive: true
    }
  },
  // 学习会详情页
  {
    path: '/studyMeetingDetails/:id',
    name: 'studyMeetingDetails',
    component: () => import('../views/studyMeetingDetails/StudyMeetingDetails.vue')
  }
];
export default routes;
