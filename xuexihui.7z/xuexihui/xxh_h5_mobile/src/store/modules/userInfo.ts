import { Module } from 'vuex';
import { RootState, UserInfo } from '@/types';
import axios from '@/plugins/axios';
import { imgDomain } from '@/assets/js/common';


const userInfo: Module<UserInfo, RootState> = {
  namespaced: true,
  state: {
    userInfoData: {
      avatar: '',
      id: '',
      mobile: '',
      name: '',
      sex: 0
    }
  },
  mutations: {
    setUserInfoData(state, payload) {
      const _obj = Object.assign(payload.data);
      // 头像地址一样 需要重绘
      _obj.avatar = `${imgDomain}/xxh/user/avatar/img/${_obj.userId}.jpg?t=${new Date().getTime()}`;
      state.userInfoData = _obj;
    }
  },
  actions: {
    getUserInfoData({ commit }, payload) {
      return new Promise((resolve, reject) => {
        axios.post('/user/app/getUserInfoByMobile', { mobile: payload }).then((res: any) => {
          commit({
            type: 'setUserInfoData',
            data: res
          });
          resolve(res);
        });
      });
    }
  }
};
export default userInfo;
