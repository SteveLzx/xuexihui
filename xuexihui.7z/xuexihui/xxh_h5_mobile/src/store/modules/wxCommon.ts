import { Module } from 'vuex';
import { RootState, WxState } from '@/types';

const wxCommon: Module<WxState, RootState> = {
  namespaced: true,
  state: {
    wxConfigData: {
      sign: ''
    }
  },
  mutations: {
    setWxConfigData(state, payload) {
      state.wxConfigData = payload;
    }
  }
};
export default wxCommon;
