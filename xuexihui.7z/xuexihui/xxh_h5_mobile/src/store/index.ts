import Vue from 'vue';
import Vuex from 'vuex';
import wxCommon from '@/store/modules/wxCommon';
import userInfo from '@/store/modules/userInfo';
import { RootState } from '@/types';

Vue.use(Vuex);

export default new Vuex.Store<RootState>({
  modules: {
    wxCommon,
    userInfo
  }
});
