import Vue, { VNode } from 'vue';

declare global {
  namespace JSX {
    // tslint:disable no-empty-interface
    interface Element extends VNode {}
    // tslint:disable no-empty-interface
    interface ElementClass extends Vue {}
    interface IntrinsicElements {
      [elem: string]: any;
    }
  }
  interface Window {
    handleComplete: any;
    handleComplete1: any;
    handleComplete2: any;
    handleComplete3: any;
    jumpComfirm: any;
    getNowId: any;
    handleRefresh: any;
    handleAdd: any;
    appGoBack: any;
    genderSettingSuccess: any;
    nameSettingSuccess: any;
    appRefresh: any;
    getImage: any;
    goBack: any;
    cancelBack: any;
    headerCallback: any;
  }

}
