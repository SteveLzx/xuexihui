type LazyLoadOptions = {
  error: string;
  loading: string;
  toast: string;
}
let _options: LazyLoadOptions;

// 找到有滚动的父元素
const scrollParent = (el: any) => {
  let parent = el;
  if (typeof window !== 'undefined') {
    while (parent) {
      if (parent === document.body || parent === document.documentElement) {
        break;
      }
      if (!parent.parentNode) {
        break;
      }
      const style = window.getComputedStyle(parent).getPropertyValue('overflow') + window.getComputedStyle(parent).getPropertyValue('overflow-x') + window.getComputedStyle(parent).getPropertyValue('overflow-y');
      if (/(scroll|auto)/.test(style)) {
        return parent;
      }
      parent = parent.parentNode;
    }
    return window;
  }
  return window;
};

const install = (_Vue: any, options: LazyLoadOptions) => {
  _options = options;
  _Vue.directive('lazy', {
    bind: (el: HTMLElement, a: any, b: any) => {
      const $el = el;
      if (el.nodeName === 'IMG') { // 仅限图片使用
        _Vue.nextTick(() => {
          const src = a.value;
          el.setAttribute('data-src', src);
          const $parent = scrollParent(el);
          console.log($parent);
          console.log(a);
        });
      }
    }
  });
};

// src、error、loading、toast取全局值或者单个值
const _valueFormatter = (value: any) => {
  let src = value;
  let { error, loading, toast } = _options;
  if (typeof value === 'object') {
    if (!value.src) console.error('Vue Lazyload warning: src还是传一下吧');
    src = value.src;
    error = value.error || _options.error;
    loading = value.loading || _options.loading;
    toast = value.toast || _options.toast;
  }
  return {
    src,
    error,
    loading,
    toast
  };
};

const LazyLoad = {
  install
};

export default LazyLoad;
