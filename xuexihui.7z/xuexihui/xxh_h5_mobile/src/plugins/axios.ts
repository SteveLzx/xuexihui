import axios from 'axios';
import Toast from '@/components/common/Toast';
// import Loading from '@/components/common/Loading';
import { domain, jsCallAppParam } from '@/assets/js/common';

axios.interceptors.request.use(
  (param: any) => {
    const config = param;
    // if (!param.url.includes('audioOrVideo')) { // 音视频上传不加loading
    //   Loading.show({ timeout: 3 });
    // }
    config.headers.Authorization = localStorage.token_app || 'eyJhbGciOiJIUzI1NiIsImV4cCI6MTU5MDA1MDEzMCwidHlwIjoiSldUIn0.eyJpZCI6NjM3MDA5NDY5ODMzNzQwNjExLCJuYW1lIjoi5ZG15ZOI5ZOI5ZG15Zi75Zi75Zi_5Zi_IiwiZXhwIjoxNTkwMDUwMTMwfQ.uy556yuB-8QWATydUBZHRmRZ2PeiRtlB_MlU7EDgD-g';
    config.headers.post['Content-Type'] = 'application/json;charset=utf-8';
    config.url = domain + config.url;
    config.url = `${config.url + (config.url.indexOf('?') >= 0 ? '&' : '?')}t=${new Date().getTime()}`;
    return config;
  },
  (err: any) => Promise.reject(err)
);

axios.interceptors.response.use(
  (response: any): any => {
    // 音视频上传不加loading
    // if (!response.request.responseURL.includes('audioOrVideo')) {
    //   Loading.hide();
    // }
    if (response.data.status && response.data.status !== 200) {
      Toast(response.data.msg);
      if (response.data.status === 401) { // token过期
        jsCallAppParam(408, {});
        return false;
      }
      return Promise.reject(response.data);
    }
    if (response.data) {
      return Promise.resolve(response.data.body || response.data.data);
    }
    return Promise.reject();
  },
  (error: any) => Promise.reject(error.response.data)
);

export default axios;
