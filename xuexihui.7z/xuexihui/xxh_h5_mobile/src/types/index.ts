export interface RootState {
  wxCommon: {
    wxConfigData: {
      sign: string;
    };
  };
}

export type WxState = {
  wxConfigData: {
    sign: string;
  };
};

export type UserInfo = {
  userInfoData: {
    avatar: '';
    id: '';
    mobile: '';
    name: '';
    sex: 0;
  };
}
