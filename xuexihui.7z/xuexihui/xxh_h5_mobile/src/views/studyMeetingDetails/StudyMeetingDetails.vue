<template>
  <div class="study-meeting-details">
    <div class="study-meeting-container">
      <div class="detail-container">
        <div class="header-title">{{studyMeetingData.meetingName}}</div>
        <div class="user-info">
          <img class="avatar" :src="studyMeetingData.createdId | avatarFilter">
          <span class="name">{{studyMeetingData.name | nameFilter}}</span>
          <span class="division">·</span>
          <span class="identity">主持人</span>
          <span class="num">{{studyMeetingData.userAccount}}人参与</span>
        </div>
        <div class="content">{{studyMeetingData.desc}}</div>
      </div>
      <div class="metting-list" v-if="studyMeetingData.themeList && studyMeetingData.themeList.length > 0">
        <div class="metting-title">会议主题</div>
        <ul class="list-container">
          <li class="metting-item" v-for="(item, index) in studyMeetingData.themeList" :key="item.themeId + index" @click="jumpTheme(item)">
            <div class="title">{{item.themeName}}</div>
            <div class="content">{{item.content}}</div>
            <div class="operation">
              <div class="time" v-if="item.beginTime">{{item.beginTime | beginTimeFilter}}</div>
              <div class="state" v-if="item.status == 2">
                <span class="state-text">会议中·{{item.talkCount}}人</span>
                <i class="iconfont">&#xe61f;</i>
              </div>
            </div>
          </li>
        </ul>
      </div>
    </div>
    <div class="join-metting" v-if="studyMeetingData.missionType === 0" @click="addMeeting">加入学习会</div>
    <!-- 学习会操作弹窗 -->
    <ActionSheet
      :showPicker="showPicker1"
      @cancel="showPicker1 = false"
      :columns="studyMeetingOperationList"
      @confirm="onConfirm1"
    />
  </div>
</template>
<script lang='ts'>
import { Component, Vue } from 'vue-property-decorator';
import { jsCallAppParam, imgDomain } from '@/assets/js/common';
import ActionSheet from '@/components/common/ActionSheet.vue';

// 自定义钩子
Component.registerHooks([
  'beforeRouteLeave'
]);

@Component({
  components: {
    ActionSheet
  },
  filters: {
    // 用户头像处理
    avatarFilter(id: string): string {
      if (id) {
        return `${imgDomain}/xxh/user/avatar/img/${id}.jpg`;
      }
      return '';
    },
    // 姓名处理
    nameFilter(name: string): string {
      if (name && name.length > 5) {
        return `${name.substring(0, 5)}...`;
      }
      return name;
    },
    // 主题开始时间处理
    beginTimeFilter(time: string): string {
      // 判断是否今天
      const newTimer = new Date();
      const newYear = `${newTimer.getFullYear()}`;
      const newM = newTimer.getMonth() + 1 > 10 ? newTimer.getMonth() + 1 : `0${newTimer.getMonth() + 1}`;
      const newD = newTimer.getDate() > 9 ? newTimer.getDate() : `0${newTimer.getDate()}`;
      console.log(`${newYear}-${newM}-${newD}`);
      if (time && (`${newYear}-${newM}-${newD}` === time.substring(0, 10))) {
        return `今天${time.substring(11, 16)}开始`;
      }
      const newTime = new Date(time.replace(/-/g, '/'));
      return `${newTime.getMonth() + 1}月${newTime.getDate()}日 ${time.substring(11, 16)}开始`;
    }
  }
})
export default class StudyMeetingDetails extends Vue {
  // 会议详情
  private studyMeetingData = {};

  // 学习会操作列表
  private studyMeetingOperationList: Array<object> = []

  // 删除学习会弹窗
  private showPicker1 = false;

  // 删除成功回到列表页，判断是否要刷新
  private goMeetingListUpData = false;

  // 页面离开执行
  beforeRouteLeave(to: any, from: any, next: any) {
    const { goMeetingListUpData } = this as any;
    console.log(goMeetingListUpData);
    if (goMeetingListUpData) {
      const toNext = to;
      toNext.meta.updateMyMeetingList = true;
    }
    next();
  }

  created() {
    // app 直接进入会议详情，返回直接回到app
    const { isFromNative } = this.$route.query;
    window.appGoBack = () => {
      if (Number(isFromNative) === 1) {
        return true;
      }
      this.$router.go(-1);
      return false;
    };
    const { id } = this.$route.params;
    this.getMeetingDetail(id).then((res: any) => {
      // 判断是否加入学习会,加入的右上角有操作按钮
      const { missionType } = res;
      let sendData = {
        title: '学习会详情'
      };
      if (missionType > 0) {
        sendData = { ...sendData, ...{ value: '2', callBack: 'headerCallback' } };
        window.headerCallback = this.headerCallback;
      }
      jsCallAppParam(100, sendData);
    });
  }

  /**
   * @method jumpTheme(进主题详情)
   * @param {any} res
   */
  jumpTheme(res: any) {
    // 会议进行中：
    // 已加入学习会人：点击进入会场-会话框页
    // 未加入学习会人：点击进入主题会详情页
    // 会议未开始：所有人点击进入主题会详情页
    // 会议已结束：所有人点击进入主题会详情页
    if (res.status === 2 && (this.studyMeetingData as any).missionType > 0) {
      // 点击进入会场-会话框页
      jsCallAppParam(411, {
        themeId: res.themeId
      });
    } else {
      jsCallAppParam(410, {
        id: res.themeId
      });
    }
  }

  /**
   * @method getMeetingDetail(请求会议详情)
   * @param {string | null} id
   */
  getMeetingDetail(id: string) {
    return new Promise((resove) => {
      this.$http.get(`/mission/app/mission/getMeetingDetail/${id}`).then((res: any) => {
        this.studyMeetingData = res;
        // 判断是主持人还是普通用户
        const { missionType } = res;
        let operationList = [];
        if (missionType === 1) {
          operationList = [
            { id: 1, text: '编辑学习会' },
            { id: 2, text: '删除学习会' }
          ];
        } else {
          operationList = [
            { id: 3, text: '退出学习会' }
          ];
        }
        this.studyMeetingOperationList = operationList;
        resove(res);
      });
    });
  }

  /**
   * @method delMeeting(删除会议)
   * @param {string} id
   */
  delMeeting(id: string) {
    return new Promise((resove) => {
      this.$http.delete(`/mission/app/mission/delMeetingById/${id}`).then((res: any) => {
        resove(res);
      });
    });
  }

  /**
   * @method addMeeting(加入会议)
   */
  addMeeting() {
    const { meetingId } = this.studyMeetingData as any;
    this.$http.post('/mission/app/mission/userAddMission', { missionId: meetingId }).then(() => {
      const { id } = this.$route.params;
      this.getMeetingDetail(id).then((res: any) => {
        // 判断是否加入学习会,加入的右上角有操作按钮
        const { missionType } = res;
        let sendData = {
          title: '学习会详情'
        };
        if (missionType > 0) {
          sendData = { ...sendData, ...{ value: '2', callBack: 'headerCallback' } };
          window.headerCallback = this.headerCallback;
        }
        jsCallAppParam(100, sendData);
      });
      // 判断是否有主题正在进行
      this.getMeetingDetail(meetingId).then(() => {
        const activeList: Array<object> = [];
        const { themeList } = this.studyMeetingData as any;
        themeList.forEach((item: any) => {
          if (item.status === 2) {
            activeList.push(item);
          }
        });
        if (activeList.length > 0) {
          // 有正在进行中的,提示最近的一个主题
          console.log(activeList);
          const themeItem = activeList.pop();
          const { themeName, themeId } = themeItem as any;
          const themeItemName = themeName.length > 10 ? `${themeName.substring(0, 10)}...` : themeName;
          // 调用app提示框
          window.cancelBack = () => false;
          window.goBack = () => {
            // 点击进入会场-会话框页
            jsCallAppParam(411, {
              themeId
            });
          };
          jsCallAppParam(407, {
            title: `主题会“${themeItemName}”正在火热进行，是否前往学习？`,
            cancelCallback: 'cancelBack',
            callBack: 'goBack',
            leftTitle: '忽略',
            rightTitle: '前往'
          });
        } else {
          // 没有在进行中的主题
          // 调用app提示框
          window.goBack = () => false;
          jsCallAppParam(413, {
            type: 1,
            title: '加入成功',
            content: '主题会开始后，我们会提前5分钟通知您，请耐心等候',
            cancelCallback: 'goBack',
            rightTitle: '知道了'
          });
        }
      });
    });
  }

  /**
   * @method signOutMeeting(退出会议)
   * @param {string} id
   */
  signOutMeeting(id: string) {
    return new Promise((resove) => {
      this.$http.post('/mission/app/mission/userExitMission', { missionId: id }).then((res: any) => {
        resove(res);
      });
    });
  }

  /** 学习会操作弹窗
   * @method onConfirm1
   * @param {any} obj
   */
  onConfirm1(obj: any) {
    // 根据id 执行不同的操作
    const { id } = obj.value;
    const { meetingId } = this.studyMeetingData as any;
    if (id === 1) {
      // 跳转到学习会编辑页面
      this.$router.push({
        path: '/addStudyMeeting',
        query: {
          id: meetingId
        }
      });
    } else if (id === 2) {
      // 删除学习会逻辑...
      // 有主题在进行中，不能删除
      this.getMeetingDetail(meetingId).then(() => {
        const activeList: Array<object> = [];
        const { themeList } = this.studyMeetingData as any;
        themeList.forEach((item: any) => {
          if (item.status === 2) {
            activeList.push(item);
          }
        });
        if (activeList.length > 0) {
          // 还有正在进行中的学习会
          // 调用app提示框
          window.goBack = () => false;
          jsCallAppParam(413, {
            title: '加入成功',
            content: '该学习会下有正在进行中的主题会，不能删除学习会',
            cancelCallback: 'goBack',
            rightTitle: '知道了'
          });
        } else {
          window.cancelBack = () => false;
          window.goBack = () => {
            this.delMeeting(meetingId).then(() => {
              this.goMeetingListUpData = true;
              this.$router.go(-1);
            });
          };
          // 调用app提示框
          jsCallAppParam(407, {
            title: '删除后学员将无法查看学习会及其主题会相关信息',
            callBack: 'cancelBack',
            cancelCallback: 'goBack',
            leftTitle: '取消',
            rightTitle: '删除学习会'
          });
        }
      });
    } else if (id === 3) {
      window.cancelBack = () => false;
      window.goBack = () => {
        // 退出学习会逻辑...
        this.signOutMeeting(meetingId).then(() => {
          this.$router.go(-1);
        });
        return false;
      };
      // 调用app提示框
      jsCallAppParam(407, {
        title: '绳锯木断，水滴石穿。再长的路，一步步也能走完，不再坚持一下吗？',
        callBack: 'goBack',
        cancelCallback: 'cancelBack',
        leftTitle: '坚持一下',
        rightTitle: '退出'
      });
    }
  }

  /** app头部标题右侧点击按钮回调
   * @method headerCallback
   */
  headerCallback() {
    this.showPicker1 = true;
  }
}
</script>
<style lang="scss" scoped>
.study-meeting-details {
  height: 100%;
  position: relative;
  overflow: hidden;
}
.study-meeting-container {
  padding-top: .14rem;
  height: 100%;
  overflow-y: auto;
  background-color: $bg;
}
.detail-container {
  padding: .4rem .3rem .3rem;
  background-color: #ffffff;
  text-align: left;
  .header-title {
    margin-bottom: .2rem;
    color: #000000;
    font-size: .44rem;
    font-weight: 500;
    font-family: PingFangSC-Semibold;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
    overflow: hidden;
    white-space:normal;
    word-break:break-all;
  }
  .user-info {
    margin-bottom: .3rem;
    display: flex;
    align-items: center;
    line-height: .24rem;
    font-size: .24rem;
    font-family: PingFangSC-Regular;
    .avatar {
      width: .4rem;
      height: .4rem;
      margin-right: .14rem;
      border-radius: 50%;
    }
    .name {
      color: #000000;
    }
    .division {
      padding: 0 .14rem;
    }
    .division, .identity {
      color: #888888;
    }
    .num {
      margin-left: .3rem;
      color: #888888;
    }
  }
  .content {
    color: #000000;
    font-size: .32rem;
    font-family: PingFangSC-Regular;
    white-space:normal;
    word-break:break-all;
  }
}
.metting-list {
  margin-bottom: 1.5rem;
  padding: .3rem .3rem 0;
  text-align: left;
  .metting-title {
    margin-bottom: .3rem;
    color: #000000;
    font-size: .34rem;
    font-family: PingFangSC-Semibold;
  }
  .list-container {
    border-radius: .2rem;
    background-color: #FFFFFF;
    padding: 0 .3rem;
  }
  .metting-item {
    padding: .3rem 0;
    border-bottom: .01rem solid $line;
    &:last-child {
      border-bottom: 0;
    }
    .title {
      color: #000000;
      font-size: .34rem;
      font-family: PingFangSC-Semibold;
      margin-bottom: .2rem;
      display: -webkit-box;
      -webkit-box-orient: vertical;
      -webkit-line-clamp: 2;
      overflow: hidden;
      white-space:normal;
      word-break:break-all;
    }
    .content {
      color: #7F7F7F;
      font-size: .28rem;
      font-family: PingFangSC-Regular;
      margin-bottom: 0.3rem;
      white-space:normal;
      word-break:break-all;
    }
    .operation {
      display: flex;
      align-content: center;
      justify-content: space-between;
      color: #B2B2B2;
      font-size: .24rem;
      font-family: PingFangSC-Regular;
      .state {
        .state-text {
          margin-right: .3rem;
          padding: .06rem .14rem;
          color: #FCC017;
          font-size: .22rem;
          border-radius: .17rem;
          font-family: PingFangSC-Regular;
          background-color: rgba(252, 192, 23, 0.2);
        }
      }
    }
  }
}
.join-metting {
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;
  height: 1.1rem;
  line-height: 1.1rem;
  background-color: $first;
  color: rgba(255, 255, 255, 1);
  font-size: .34rem;
  text-align: center;
  font-family: PingFangSC-Medium;
}
</style>
