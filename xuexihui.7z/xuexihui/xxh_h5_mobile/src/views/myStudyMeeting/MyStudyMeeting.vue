<template>
  <div class="my-study-meeting">
    <div class="meeting-list" v-if="studyMeetingList.length">
      <OptionList
        :title="item.name"
        :border="index != (studyMeetingList.length -1)"
        select
        :selectValue="selectValue == index"
        v-for="(item,index) in studyMeetingList"
        :key="index"
        @click="handleChange(item,index)"
      ></OptionList>
    </div>
    <div class="add-study-meeting" @click="handleCreate">+ 新建学习会</div>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import OptionList from '@/components/page/OptionList.vue';
import { jsCallAppParam, getQueryString } from '@/assets/js/common';

@Component({
  components: { OptionList }
})
export default class MyStudyMeeting extends Vue {
  // 学习会列表
  studyMeetingList = [];

  // 选中索引
  selectValue = 0;

  created() {
    const id = getQueryString('id');
    this.getMyMeetingList(id);
    jsCallAppParam(100, {
      title: '我的学习会'
    });
    window.appGoBack = () => {
      this.$router.go(-1);
      return false;
    };
  }

  /** 获取学习会列表
   * @method getMyMeetingList
   * @param {string | null} id
   */
  getMyMeetingList(id: string | null) {
    this.$http.post('/mission/app/mission/getMeetingList')
      .then((res: any) => {
        if (res.MeetingNames) {
          this.studyMeetingList = res.MeetingNames;
          if (id) {
            this.studyMeetingList.forEach((item: any, index: number) => {
              if (!localStorage.getItem('isCreate') && id === item.id) {
                this.selectValue = index;
              } else if (localStorage.getItem('isCreate')) {
                // 如果是创建学习会，默认选中最新创建的
                this.selectValue = 0;
              }
            });
          }
          this.$bus.$emit('chooseStudyMeeting', res.MeetingNames[this.selectValue]);
        }
      });
  }

  /** 学习会列表选择事件
   * @method handleChange
   * @param {any}item {number} index
   */
  handleChange(item: any, index: number) {
    this.selectValue = index;
    this.$bus.$emit('chooseStudyMeeting', item);
    setTimeout(() => {
      this.$router.go(-1);
    }, 10);
  }

  /** 创建学习会
   * @method handleCreate
   */
  handleCreate() {
    // 添加创建学习会标记
    localStorage.setItem('isCreate', '1');
    this.$router.push({
      name: 'AddStudyMeeting',
      params: {
        flag: '1'
      }
    });
  }
}
</script>

<style lang="scss" scoped>
.my-study-meeting {
  background-color: #f7f7f7;
  padding-top: 0.16rem;
  width: 100%;
  min-height: 100%;
  // 学习会列表
  .meeting-list {
    margin-bottom: 0.16rem;
    width: 100%;
    background-color: #fff;
  }
  // 新建学习会按钮
  .add-study-meeting {
    width: 100%;
    padding: 0.32rem 0;
    text-align: center;
    font-size: 0.34rem;
    line-height: 0.34rem;
    color: #000;
    font-weight: 500;
    background-color: #fff;
  }
}
</style>
