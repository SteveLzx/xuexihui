<template>
  <div class="set-meeting">
    <!-- 测试 -->
    <!-- <OptionList title="测试" choose @click="handleComplete" chooseValue="完成"></OptionList> -->

    <template v-if="agendaList.length">
      <OptionList
        title="会议议程"
        choose
        :disabled="!isEditable"
        @click="handleChooseMeeting"
        :chooseValue="meetingName"
        placeholder="选择议程"
      ></OptionList>
      <!-- 主题演讲 -->
      <div class="setting-content" v-if="meetingType === 0">
        <div class="setting">
          <div class="title">演讲设置</div>
          <OptionList
            title="演讲人"
            @click="handleChooseSpeaker"
            :disabled="!isEditable"
            border
            choose
            :chooseValue="speaker"
            placeholder="搜索手机号"
          ></OptionList>
          <OptionList
            title="用时"
            @click="showPicker2 = true"
            border
            choose
            :chooseValue="timeUse"
            placeholder="请选择时长"
          ></OptionList>
          <!-- <OptionList
            title="授课方式"
            @click="handleChooseStyle"
            choose
            :chooseValue="teachStyle"
            placeholder="选择授课方式"
          ></OptionList> -->
        </div>
        <!-- <div class="upload" v-show="teachStyleType === 1">
          <div class="title">
            上传素材
            <span>（至少一种）</span>
          </div>
          <OptionList
            title="音频"
            border
            file="audio"
            @uploadComplete="handleChange"
            @fileDelete="handleDelete"
            :fileValue="audio"
            placeholder="上传音频版内容"
          ></OptionList>
          <OptionList
            title="视频"
            file="video"
            @uploadComplete="handleChange1"
            @fileDelete="handleDelete1"
            :fileValue="video"
            placeholder="上传视频版内容"
          ></OptionList>
        </div>
        <div class="setting-title">文稿设置</div>
        <div class="edit" placeholder="点击编辑文稿内容" v-html="content" @click="handleJump"></div>
        <div class="placeholder1" v-if="content"></div> -->
      </div>
      <!-- 小组轮流发言 || 自由讨论-->
      <div class="setting-content" v-if="meetingType === 1 || meetingType === 2">
        <div class="title">议程设置</div>
        <OptionList
          @click="showPicker2 = true"
          :title="settingTitle"
          choose
          :chooseValue="timeUse"
          :placeholder="placeholder"
        ></OptionList>
      </div>
      <!-- 选择会议议程主题 -->
      <ActionSheet
        v-if="agendaList.length"
        :showPicker="showPicker"
        @cancel="showPicker = false"
        :columns="agendaList"
        @confirm="onConfirm"
      />
      <!-- 选择授课方式 -->
      <!-- <ActionSheet
        :showPicker="showPicker1"
        @cancel="showPicker1 = false"
        :columns="teachStyleList"
        @confirm="onConfirm1"
      /> -->
      <!-- 用时 -->
      <PopupPicker
        :showPicker="showPicker2"
        @confirm="onConfirm2"
        :columns="timeUseList"
        :default-index="defaultIndex"
        @cancel="showPicker2 = false"
      />

    </template>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Watch } from 'vue-property-decorator';
import OptionList from '@/components/page/OptionList.vue';
import { jsCallAppParam } from '@/assets/js/common';
import ActionSheet from '@/components/common/ActionSheet.vue';
import DateTimePicker from '@/components/common/DateTimePicker.vue';
import PopupPicker from '@/components/common/PopupPicker.vue';

@Component({
  components: {
    OptionList,
    ActionSheet,
    DateTimePicker,
    PopupPicker
  }
})
export default class SettingMeeting extends Vue {
  // 0主题会议，1自由讨论  2 轮流发言
  meetingType = 4;

  // 0 直播 1 录播
  teachStyleType = 1;

  // 用时默认选中3分钟
  defaultIndex = 2;

  // 议程进行状态
  status = 1;

  // 进行中的议程id
  nowId = '';

  // 标签id
  tagId: number;

  // 议程标题
  meetingName = '';

  // 临时存储议程标题
  tempMeetingName = '';

  // 完成按钮文字颜色
  color = '#B2B2B2';

  // 完成按钮背景颜色
  bgColor = '#F2F2F2';

  // 演讲人
  speaker = '';

  // 临时存储
  tempSpeaker = '';

  // 演讲人id
  speakerId = '';

  // 用时
  timeUse = '';

  // 临时存储用时
  tempTimeUse = '';

  // 占位内容
  placeholder = '';

  // 授课方式
  teachStyle = '';

  // 音频
  audio = {
    result: '',
    name: ''
  };

  // 视频
  video = {
    result: '',
    name: ''
  };

  // 文稿内容
  content = '';

  // 选择会议议程主题
  showPicker = false;

  // 选择授课方式
  // showPicker1 = false;

  // 用时
  showPicker2 = false;

  // 标签集合
  agendaList: Array<object> = [];

  // 授课方式
  teachStyleList: Array<object> = [
    { id: 1, text: '直播演讲' },
    { id: 2, text: '上传录播文件' }
  ];

  // 用时集合
  timeUseList: Array<object> = [];

  // 临时存储数据
  tempData = {};

  created() {
    // ESLint Unary operator '++' used i++ 换成 i += 1
    for (let i = 1; i <= 120; i += 1) {
      this.timeUseList.push({
        id: i,
        text: `${i}分钟`
      });
    }
    window.handleComplete1 = this.handleComplete;
    window.getNowId = this.getNowId;
    this.init();
  }

  /**
   * 缓存函数
   */
  activated() {
    jsCallAppParam(100, {
      title: '设置议程',
      btnText: '完成',
      backText: '取消',
      color: this.color,
      bgColor: this.bgColor,
      callBack: 'handleComplete1'
    });
    if (this.$route.params.params) {
      // 编辑议程时，临时存储议程信息，防止在跳转的时候路由参数丢失
      this.tempData = this.$route.params.params;
      // 路由参数存在时取出对应的数据显示在页面上
      const { params }: any = this.$route.params;
      this.meetingName = params.name;
      this.tempMeetingName = params.name;
      this.timeUse = params.ext.timeUse;
      this.tempTimeUse = params.ext.timeUse;
      this.status = params.status;
      // 用时默认选中
      this.timeUseList.forEach((item: any, index: number) => {
        if (item.text === this.timeUse) {
          this.defaultIndex = index;
        }
      });
      // 设置演讲人
      if (params.ext.speaker) {
        this.speaker = `${params.ext.speaker.phone} ${params.ext.speaker.name}`;
        this.tempSpeaker = `${params.ext.speaker.phone} ${params.ext.speaker.name}`;
      }
      // 存储保存议程时对应的议程id
      this.tagId = params.ext.tagId;
      // 主题类型回显
      this.agendaList.forEach((item: any, index: number) => {
        if (params.tagId === item.id) {
          this.meetingType = index;
        }
      });
      // this.teachStyle = params.ext.teachStyle;
      // this.content = params.ext.content;
      // 音视频如果存在，格式化其名字
      // this.video = params.ext.video;
      // if (params.ext.video) {
      //   this.video.name = this.nameTransform(params.ext.video.name);
      // }
      // this.audio = params.ext.audio;
      // if (params.ext.audio) {
      //   this.audio.name = this.nameTransform(params.ext.audio.name);
      // }
    } else if (this.$route.params.flag && !this.$route.params.params) { // 新建主题会，清空数据
      this.meetingName = '';
      this.timeUse = '';
      this.tempTimeUse = '';
      this.speaker = '';
      this.tempSpeaker = '';
      this.speakerId = '';
      this.showPicker = false;
      this.showPicker2 = false;
      this.meetingType = 4;
      this.defaultIndex = 2;
      // this.content = '';
      // this.teachStyle = '';
      // this.video = { result: '', name: '' };
      // this.audio = { result: '', name: '' };
    }
    this.appCommon();
    // 设置演讲人
    this.$bus.$once('setSpeaker', (res: any) => {
      this.speaker = `${res.mobile} ${res.name}`;
      this.speakerId = res.userId;
    });
    // 设置演讲内容
    // this.$bus.$once('setDraft', (res: string) => {
    //   this.content = res;
    // });
    // console.log(this.meetingType, this.tempData);
  }

  /** 初始化数据
   * @method init
   */
  init() {
    if (this.$route.params.params) {
      const { params }: any = this.$route.params;
      this.getAgendaList(params.ext.tagId);
    } else {
      this.getAgendaList('');
    }
  }

  /** 获取正在进行的议程id
   * @method getNowId
   * @param {String} id
   */
  getNowId(id: string) {
    this.nowId = id;
  }

  /** 判断是否是进行的议程
   * @method handleJudge
   * @returns {Boolean}
   */
  handleJudge() {
    // 进行中的议程
    if (this.status === 2 || this.nowId === (this.$route.params.params as any).id) {
      let { setDate } = this.$route.params.params as any;
      setDate = setDate.replace(/-/g, '/');
      const start = new Date(setDate).getTime();
      const now = new Date().getTime();
      const total = parseInt(this.timeUse, 0) * 60 * 1000;
      // 进行中的议程时长大于一分钟
      return total - (now - start) <= 60000;
    }
    return false;
  }

  /** 根据议程id查询议程
   * @method getAgendaById
   */
  getAgendaById(id: number) {
    this.$http.get('/mission/app/mission/getAgendaById', { params: { id } }).then((res: any) => {
      console.log(res);
    });
  }

  /** 调用app共用方法
   * @method appCommon
   */
  appCommon() {
    window.goBack = this.goBack;
    window.appGoBack = () => {
      if (
        this.meetingName
        || this.speaker
        || this.timeUse
      ) {
        jsCallAppParam(407, {
          title: '退出后编辑内容将不被保存，确定要退出吗？',
          callBack: 'goBack',
          leftTitle: '取消',
          rightTitle: '确定'
        });
      } else {
        this.$router.go(-1);
      }
      return false;
    };
  }

  /** app回退
   * @method goBack
   */
  goBack() {
    this.meetingName = '';
    this.timeUse = '';
    this.speaker = '';
    this.speakerId = '';
    this.tempTimeUse = '';
    this.tempSpeaker = '';
    // this.content = '';
    // this.teachStyle = '';
    // this.video = { result: '', name: '' };
    // this.audio = { result: '', name: '' };
    // this.showPicker1 = false;
    this.meetingType = 4;
    this.defaultIndex = 2;
    this.showPicker = false;
    this.showPicker2 = false;
    this.$router.go(-1);
    return false;
  }

  /** 获取标签
   * @method getAgendaList
   * @param {string} id
   */
  getAgendaList(id: string) {
    this.$http.get('/tag/app/tag/getAgendaList').then((res: any) => {
      this.agendaList = [];
      if (res) {
        let { agendaTagRes } = res;
        // 隐藏小组轮流发言模块
        agendaTagRes = agendaTagRes.filter((item: any) => item.name !== '小组轮流发言');
        agendaTagRes.forEach((item: any, index: number) => {
          const json = JSON.stringify(item).replace(/name/g, 'text');
          this.agendaList.push(JSON.parse(json));
          if (id && id === item.id) {
            this.meetingType = index;
          }
        });
      }
    });
  }

  /** 选择演讲人
   * @method handleChooseSpeaker
   */
  handleChooseSpeaker() {
    // 不可编辑状态
    if (!this.isEditable) return;
    this.$router.push('/settingSpeaker');
  }

  /** 右侧完成按钮
   * @method handleComplete
   */
  handleComplete() {
    if (!this.btnStatus) return;
    const params = {
      name: this.meetingName,
      ext: '',
      tagId: this.tagId
    };
    const data: any = {
      tagId: this.tagId,
      meetingType: this.meetingType
    };
    if (this.meetingType === 0) {
      data.speaker = {
        phone: this.speaker.split(' ')[0],
        name: this.speaker.split(' ')[1],
        speakerId: this.speakerId
      };
      data.timeUse = this.timeUse;
      // data.teachStyle = this.teachStyle;
      // data.audio = this.audio;
      // data.video = this.video;
      // data.content = this.content;
    } else {
      data.timeUse = this.timeUse;
    }
    if (localStorage.getItem('editMeeting')) {
      // 编辑议程,此时路由中的参数可能丢失了，取出之前临时存储的数据来显示页面
      (params as any).id = (this.tempData as any).id;
      if (this.handleJudge()) {
        this.$xxhToast('当前剩余时长小于1分钟');
        return;
      }
      if (this.status === 2 && parseInt(this.timeUse, 0) <= parseInt((this.tempData as any).ext.timeUse, 0)) {
        this.$xxhToast('不可小于当前时长');
        return;
      }
      params.ext = JSON.stringify(data);
      this.$http.post('/mission/app/mission/updateAgenda', params).then((res: any) => {
        if (res) {
          // 通知app编辑议程了
          jsCallAppParam(412, {
            type: 3
          });
          this.$bus.$emit('updateMeetingData', params);
          this.$router.go(-1);
        }
      });
    } else {
      // 新增议程
      params.ext = JSON.stringify(data);
      console.log('params', params);
      console.log('data', data);
      this.$http.post('/mission/app/mission/createAgenda', params).then((res: any) => {
        if (res) {
          (params as any).id = res;
          this.$bus.$emit('setMeetingData', params);
          this.$router.go(-1);
        }
      });
    }
  }

  /** 选择议程
   * @method handleChooseMeeting
   */
  handleChooseMeeting() {
    // 不可编辑状态
    if (!this.isEditable) return;
    this.showPicker = true;
  }

  /** 选择议程确认按钮
   * @method onConfirm
   * @param {any} obj
   */
  onConfirm(obj: any) {
    // if (this.audio && this.audio.name && !this.audio.name.includes('...')) {
    //   this.audio.name = this.nameTransform(this.audio.name);
    // }
    // if (this.video && this.video.name && !this.video.name.includes('...')) {
    //   this.video.name = this.nameTransform(this.video.name);
    // }
    this.meetingName = obj.value.text;
    this.meetingType = obj.index;
    this.tagId = obj.value.id;
    if (this.meetingType === 0) {
      this.timeUse = '';
    }
  }

  // /** 选择授课方式
  //  * @method handleChooseStyle
  //  */
  // handleChooseStyle() {
  //   this.showPicker1 = true;
  // }

  // /** 选择授课方式确认按钮
  //  * @method onConfirm1
  //  * @param {any} obj
  //  */
  // onConfirm1(obj: any) {
  //   this.teachStyle = obj.value.text;
  //   this.teachStyleType = obj.index;
  // }

  /** 用时选择
   * @method onConfirm2
   * @param {any} obj
   */
  onConfirm2(obj: any) {
    this.timeUse = obj.value.text;
    this.defaultIndex = obj.index;
  }

  /** 跳转到文稿编辑
   * @method handleJump
   */
  // handleJump() {
  //   this.$router.push({
  //     name: 'EditDraft',
  //     params: {
  //       content: this.content
  //     }
  //   });
  // }

  /** 上传音频
   * @method handleChange
   * @param {any} res
   */
  // handleChange(res: any) {
  //   this.audio = res;
  // }

  /** 删除音频
   * @method handleDelete
   */
  // handleDelete() {
  //   this.audio = {
  //     result: '',
  //     name: ''
  //   };
  // }

  /** 上传视频
   * @method handleChange1
   * @param {any} res
   */
  // handleChange1(res: any) {
  //   this.video = res;
  // }

  /** 删除视频
   * @method handleDelete1
   */
  // handleDelete1() {
  //   this.video = {
  //     result: '',
  //     name: ''
  //   };
  // }

  /** 音视频名字过长转换
   * @method nameTransform
   * @param {string} name 视频名
   * @return {string} 视频名
   */
  // nameTransform(name: string) {
  //   if (!name) return '';
  //   const arr = name.split(' ');
  //   const nameStr = arr[0].substring(0, arr[0].lastIndexOf('.'));
  //   const nameStr1 = arr[0].substring(arr[0].lastIndexOf('.'), arr[0].length);
  //   let str = '';
  //   if (nameStr.length > 6) {
  //     str = `${nameStr.substring(0, 6)}... ${nameStr1} ${arr[1]}`;
  //   } else {
  //     str = `${name} ${arr[1]}`;
  //   }
  //   return str;
  // }

  /** 计算属性 设置议程标题
   * @method settingTitle
   */
  get settingTitle() {
    if (this.meetingType === 2 && !this.$route.params.params) {
      this.timeUse = '3分钟';
      this.placeholder = '';
    } else if (this.meetingType === 1 && !this.$route.params.params) {
      this.timeUse = '';
      this.placeholder = '请选择讨论时长';
    } else if (this.meetingType === 0) {
      this.timeUse = '';
    }
    return this.meetingType === 2 ? '单人发言时长' : '讨论时长';
  }

  /**
   * 是否可编辑
   */
  get isEditable() {
    // 编辑状态下根据议程状态判断是否可编辑，会前可编辑
    if (localStorage.getItem('editMeeting')) {
      return this.status && this.status === 1;
    }
    // 创建状态下都可编辑
    return true;
  }

  /** 头部返回按钮状态
   *  @method btnStatus
   */
  get btnStatus() {
    // 编辑状态下
    if (localStorage.getItem('editMeeting')) {
      // 主题会议，且议程未开始状态
      if (this.isEditable && this.speaker) {
        return this.meetingName !== this.tempMeetingName
        || this.speaker !== this.tempSpeaker
        || this.timeUse !== this.tempTimeUse;
      }
      // 其他形式议程
      return this.meetingName !== this.tempMeetingName || this.timeUse !== this.tempTimeUse;
    }
    // 创建状态下
    if (!this.meetingType) { // 主题演讲
      return this.meetingName
            && this.speaker
            && this.timeUse;
    }
    return this.meetingName && this.timeUse;
    // if (!this.meetingType) {
    //   if (!this.teachStyleType) { // 直播
    //     return Boolean(this.meetingName)
    //       && Boolean(this.speaker)
    //       && Boolean(this.timeUse)
    //       && Boolean(this.teachStyle)
    //       && Boolean(this.content);
    //   }
    //   return Boolean(this.meetingName)
    //       && Boolean(this.speaker)
    //       && Boolean(this.timeUse)
    //       && Boolean(this.teachStyle)
    //       && Boolean(this.content)
    //       && (Boolean(this.audio.result)
    //       || Boolean(this.video.result));
    // }
    // return Boolean(this.meetingName) && Boolean(this.timeUse);
  }

  /**
   * 监听头部返回按钮状态
   */
  @Watch('btnStatus')
  statusChange(val: boolean) {
    if (val) {
      this.color = '#ffffff';
      this.bgColor = '#2CC07C';
    } else {
      this.color = '#B2B2B2';
      this.bgColor = '#F2F2F2';
    }
    jsCallAppParam(100, {
      title: '设置议程',
      btnText: '完成',
      backText: '取消',
      color: this.color,
      bgColor: this.bgColor,
      callBack: 'handleComplete1'
    });
  }
}
</script>
<style lang="scss">
.set-meeting {
  width: 100%;
  height: 100%;
  background-color: #f7f7f7;
  padding-top: 0.16rem;
  .setting-content {
    .title {
      padding: 0.4rem 0 0.4rem 0.3rem;
      color: #7f7f7f;
      font-size: 0.3rem;
      line-height: 0.3rem;
      text-align: left;
      font-weight: 500;
    }
    .setting {
      margin-bottom: 0.16rem;
    }
    .upload {
      .title {
        padding: 0.32rem 0 0 0.3rem;
        background-color: #fff;
        color: #000;
        font-size: 0.34rem;
        line-height: 0.34rem;
        font-weight: 500;
        text-align: left;
        span {
          color: #7f7f7f;
        }
      }
      .border-box {
        >span {
          color: #B2B2B2;
        }
      }
    }
    .setting-title {
      padding: 0.4rem 0 0.3rem 0.4rem;
      color: #7f7f7f;
      font-size: 0.3rem;
      line-height: 0.3rem;
      text-align: left;
      font-weight: 500;
    }
    .edit {
      width: 100%;
      min-height: 1.62rem;
      padding: 0.3rem 0.3rem;
      font-size: 0.34rem;
      color: #7F7F7F;
      font-weight: 500;
      text-align: left;
      background-color: #fff;
      box-sizing: border-box;
      word-break: break-all;
      &:empty:before {
        content: attr(placeholder);
        opacity: 0.5;
      }
      img {
        width: 100%;
      }
    }
    .placeholder1 {
      width: 100%;
      height: 1rem;
      background-color: #fff;
    }
  }
}
</style>
