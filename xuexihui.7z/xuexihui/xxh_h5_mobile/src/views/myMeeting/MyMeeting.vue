<template>
  <div class="my-meeting">
    <LoadRefresh ref="loadRefresh" @pull-callback="pullCallback"  @load-callback="loadCallback">
      <template v-if="meetingList.length > 0">
        <div class="meeting-list" v-for="(item, index) in meetingList" :key="index" @click="tomeetingDel(item.meetingId)">
          <div class="header-box">
            <img class="header-img" :src="avatarDomain + item.userId+'.jpg'" >
            <div class="header-title">
              <div class="name">{{item.name}}</div>
              <div class="text">创建了学习会</div>
            </div>
          </div>
          <div class="meeting-title">{{item.meetingName}}</div>
          <div class="meeting-text">{{item.content}}</div>
          <div class="partake-num">{{item.userAccount}}人参与</div>
        </div>
      </template>
      <template v-if="meetingList.length == 0">
        <div class="empty-box">
          <div class="empty-icon"></div>
          <div class="empty-text">暂无内容</div>
        </div>
      </template>
    </LoadRefresh>
  </div>
</template>

<script lang="ts">
import Vue from 'vue';
import { Component, Ref } from 'vue-property-decorator';
import { jsCallAppParam, imgDomain } from '@/assets/js/common';
import LoadRefresh from '@/components/common/LoadRefresh.vue';

Component.registerHooks([
  'beforeRouteLeave'
]);

@Component({
  components: { LoadRefresh }
})
export default class MyStudyMeeting extends Vue {
  @Ref() loadRefresh: LoadRefresh;

  avatarDomain = `${imgDomain}/xxh/user/avatar/img/`;

  pageNo = 0;

  meetingList: Array<any> = [];

  created() {
    this.$loading.show();
    this.getMeetingList(2);
  }

  activated() {
    window.appGoBack = () => true;
    jsCallAppParam(100, {
      title: '我的会议'
    });

    if (this.$route.meta.isBack) {
      const cache: any = window.sessionStorage.getItem('myMeetingScroll');
      const loadBox: any = document.querySelector('#load-box');
      if (loadBox) {
        loadBox.scrollTo(0, cache);
      }
    }
    this.$route.meta.isBack = false;

    // 从详情返回时，如果详情删除了会议，则重新请求数据
    if (this.$route.meta.updateMyMeetingList) {
      this.getMeetingList(1);
    }
  }

  beforeRouteLeave(to: any, from: any, next: any) {
    this.$route.meta.isBack = to.name === 'studyMeetingDetails';
    next();
  }

  // 获取我的会议列表
  getMeetingList(key?: number) {
    if (key === 1) this.pageNo = 0;
    const sendData = {
      idx: this.pageNo,
      size: 20
    };
    this.$http.get('/mission/app/mission/getMyMeetingList', { params: sendData }).then((res: any) => {
      if (res.getMyMeetingListRes) {
        this.meetingList = this.pageNo === 0 ? res.getMyMeetingListRes : [...this.meetingList, ...res.getMyMeetingListRes];
        if (res.getMyMeetingListRes.length < 20) {
          this.loadRefresh.loadSuccess(false, true, true);
        } else {
          this.loadRefresh.loadSuccess();
        }
      } else {
        this.loadRefresh.loadSuccess(false, true, true);
      }
      if (key === 1) {
        this.loadRefresh.pullSuccess();
      } else if (key === 2) {
        this.$loading.hide();
      }
    });
  }

  // 访问我的学习会详情
  tomeetingDel(id: string) {
    // 保存滚动高度
    const div: any = document.querySelector('#load-box');
    window.sessionStorage.setItem('myMeetingScroll', div.scrollTop);
    this.$router.push(`/studyMeetingDetails/${id}`);
  }

  // 刷新回调
  pullCallback() {
    this.getMeetingList(1);
  }

  // 下拉加载回调
  loadCallback() {
    this.pageNo = Number(this.pageNo) + 1;
    this.getMeetingList();
  }
}
</script>

<style lang="scss" scoped>
.my-meeting{
  width: 100%;
  height: 100%;
  background-color: #f7f7f7;
  .meeting-list{
    background-color: rgba(255, 255, 255, 1);
    padding: 0.3rem;
    box-sizing: content-box;
    margin-top: 0.14rem;
    .header-box{
      display: flex;
      justify-content: flex-start;
      margin-bottom: 0.3rem;
      .header-img{
        width: 0.6rem;
        height: 0.6rem;
        border-radius: 50%;
        border: none;
        margin-right: 0.1rem;
      }
      .header-title{
        .name{
          height: 0.28rem;
          line-height: 0.28rem;
          color: rgba(0, 0, 0, 1);
          font-size: 0.28rem;
          text-align: left;
          font-family: PingFangSC-Regular;
          margin-bottom: 0.08rem;
        }
        .text{
          height: 0.24rem;
          line-height: 0.24rem;
          color: rgba(178, 178, 178, 1);
          font-size: 0.24rem;
          text-align: left;
          font-family: PingFangSC-Regular;
        }
      }
    }
    .meeting-title{
      /*height: 0.34rem;*/
      line-height: 0.38rem;
      color: rgba(0, 0, 0, 1);
      font-size: 0.34rem;
      text-align: left;
      font-family: PingFangSC-Semibold;
      font-weight: 600;
      margin-bottom: 0.2rem;
      overflow: hidden;
      text-overflow: ellipsis;
      /*white-space: nowrap;*/
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      display: -webkit-box;
    }
    .meeting-text{
      line-height: 0.4rem;
      color: rgba(127, 127, 127, 1);
      font-size: 0.28rem;
      text-align: left;
      font-family: PingFangSC-Regular;
      margin-bottom: 0.2rem;
      overflow : hidden;
      text-overflow: ellipsis;
      display: -webkit-box;
      -webkit-line-clamp: 3;
      -webkit-box-orient: vertical;
    }
    .partake-num{
      height: 0.24rem;
      line-height: 0.24rem;
      color: rgba(178, 178, 178, 1);
      font-size: 0.24rem;
      text-align: left;
      font-family: PingFangSC-Regular;
      padding-top: 0.2rem;
      border-top: 1px solid rgba(229, 229, 229, 1);
    }
  }
  .empty-box{
    width: 100%;
    height: 100%;
    .empty-icon{
      height: 4.53rem;
      padding-top: 1.73rem;
    }
    .empty-text{
      height: .42rem;
      line-height: 0.42rem;
      color: rgba(178, 178, 178, 1);
      font-size: 0.3rem;
      text-align: center;
      font-family: PingFangSC-Regular;
      margin-top: 0.44rem;
    }
  }
}
</style>
