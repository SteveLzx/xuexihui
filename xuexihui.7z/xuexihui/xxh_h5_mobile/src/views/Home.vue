<template>
  <div class="home">
    <LoadRefresh ref="loadRefresh"
                 @pull-callback="pullCallback"
                 @load-callback="loadCallback">
      <UploadImg @getImg="getImg" maxSize="5024" style="background: gray;">
      <div class="upload"></div>
    </UploadImg>
      <img :src="imgSrc" alt="" width="300px">
      <input type="file" @change="addFile">
      <img alt="Vue logo" src="../assets/logo.png">
      <img alt="Vue logo" src="../assets/logo.png">
      <img alt="Vue logo" src="../assets/logo.png" v-lazy="'我是图片1'">
      <img alt="Vue logo" src="./Img_nor@2x.png" v-lazy="'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1584097916476&di=dc3006e355b2eb8c9068f1bf76fdae34&imgtype=0&src=http%3A%2F%2Fa3.att.hudong.com%2F68%2F61%2F300000839764127060614318218_950.jpg'">
      <img alt="Vue logo" src="../assets/logo.png">
      <img alt="Vue logo" src="../assets/logo.png">
      <input type="text" @keydown.enter="addFeature" v-model="fValue">
      {{foo}}
      <ul>
        <li v-for="item in features" :key="item">{{item}}</li>
      </ul>
      <Popup
        v-model="showPopup"
        :id='popupId'
        :title="'标题'"
        :text="'内容'"
        :cancel-text="'取消'"
        :confirm-text="'确认'"
        :cancel-color="'#000000'"
        :confirm-color="'#2CC07C'"
        @cancelCallBack="cancelCallBack"
        @confirmCallBack="confirmCallBack"
      ></Popup>
    </LoadRefresh>
  </div>
</template>

<script lang='ts'>
import {
  Component,
  Vue,
  Prop,
  Emit,
  Watch,
  Ref
} from 'vue-property-decorator';
import {
  namespace,
  State,
  Action
} from 'vuex-class';
import { WxState } from '@/types';
import UploadImg from '@/components/common/UploadImg.vue';
import LoadRefresh from '@/components/common/LoadRefresh.vue';
import Popup from '@/components/common/Popup.vue';

const wxCommon = namespace('wxCommon');

type FileData = {
  data: string;
  newFile: File;
};

@Component({
  components: { UploadImg, LoadRefresh, Popup }
})
export default class Home extends Vue {
  @State counter: number;

  @Action add: any;

  @Ref() loadRefresh: LoadRefresh;

  @wxCommon.State('wxConfigData')
  wxConfigData: WxState;

  features: string[] = [];

  file: File;

  fValue = '';

  private imgSrc = '';

  public showPopup = true;

  public popupId = 1;

  @Prop() msg!: string;

  created() {
    this.features = [];
  }

  get foo() {
    return this.features.length;
  }

  @Emit()
  addFeature(e: KeyboardEvent) {
    const inp = e.target as HTMLInputElement;
    this.features.push(inp.value);
    return 'a';
  }

  addFile(e: Event) {
    const { files } = e.target as HTMLInputElement;
    if (files) {
      [this.file] = Array.from(files);
    }
  }

  getImg(file: FileData) {
    this.imgSrc = file.data;
  }

  private cancelCallBack(data: number) {
    console.log(data);
    this.showPopup = false;
  }

  private confirmCallBack(data: boolean) {
    console.log(data);
    this.showPopup = false;
  }

  pullCallback() {
    setTimeout(() => {
      this.loadRefresh.pullSuccess();
    }, 1500);
    console.log('收到信息要加载了');
  }

  loadCallback() {
    setTimeout(() => {
      this.loadRefresh.loadSuccess(true);
    }, 1500);
    console.log('加载更多');
  }

  @Watch('features')
  changeValue(val: string[], val2: string[]): void {
    window.console.log(val.length, val2.length);
  }

  @Watch('fValue')
  changeValue2(val: string): void {
    window.console.log(val);
  }
}
</script>
