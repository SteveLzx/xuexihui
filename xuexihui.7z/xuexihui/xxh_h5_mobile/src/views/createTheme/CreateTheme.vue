<template>
  <div class="create-theme">
    <!-- 测试 -->
    <!-- <OptionList title="测试" choose @click="handleAdd" :chooseValue="btnText"></OptionList> -->

    <div v-if="isDataShow">
      <div class="basic-setting">基础设置</div>
      <div class="basic-setting-box">
        <OptionList
          title="会议名称"
          v-model="meetingName"
          border
          input
          :disabled="meetingStatus1 != 0 && meetingStatus1 != 9999 && meetingStatus != 3"
          maxlength="20"
          placeholder="输入会议名称"
        ></OptionList>
        <OptionList
          title="归属学习会"
          @click="handleChooseMeeting"
          border
          :disabled="meetingStatus1 != 0 && meetingStatus1 != 9999 && meetingStatus != 3"
          choose
          :chooseValue="studyMeetingName.name"
          placeholder="请选择学习会"
        ></OptionList>
        <OptionList
          title="近期召开"
          :disabled="meetingStatus != 1"
          border
          switch
          :value="recentStart"
        ></OptionList>
        <OptionList
          v-show="recentStart"
          title="开始时间"
          @click="handleChooseTime"
          :disabled="isEditable"
          choose
          :chooseValue="startTime"
          placeholder="请选择开始时间"
        ></OptionList>
      </div>
      <div class="basic-setting">议程设置</div>
      <div class="meeting-setting">
        <draggable tag="ul" v-model="list" :move="onMove" filter=".item">
          <li
            class="content"
            :class="[item.status == 3 ? 'disabled' : '', item.status && item.status != 1 ? 'item' : '']"
            v-for="(item,index) in list"
            :key="item.id"
            @touchstart="handleDisabled(item, $event)"
          >
            <div class="left">
              <i class="iconfont" v-if="item.status != 2">&#xe621;</i>
              <span v-else @click="handleJumpMeeting(item, index)">跳过</span>
            </div>
            <div class="center" @click="handleJump(item)">
              <div
                class="progress-box"
                :style="{
                  width: getWidth(item),
                  'border-top-right-radius': getWidth(item) == '100%' ? '0.08rem' : '',
                  'border-bottom-right-radius': getWidth(item) == '100%' ? '0.08rem' : ''
                }"></div>
              <div class="progress">
                <div class="progress-content">
                  <span>{{ item.name }}</span>
                  <span>
                    {{ item.ext.timeUse }}
                    <i class="iconfont">&#xe61f;</i>
                  </span>
                </div>
              </div>
            </div>
            <div class="right" :class="item.status == 2 ? 'disabled' : ''" @touchstart="handleDeleteMeeting(item, index)">
              <i class="iconfont">&#xe61d;</i>
            </div>
          </li>
        </draggable>
        <div class="add-meeting" v-if="meetingStatus1 != 9999 && meetingStatus != 3 && meetingStatus != 4" @click="handleAddMeeting">+添加议程</div>
      </div>
      <!-- 内容设置 -->
      <div class="content-setting-title">内容设置</div>
      <EditInput
        ref="editInput"
        placeholder="点击添加会议简介（限10字以上70字以内）"
        :maxLength="maxLength"
        :minLength="minLength"
        :minHeight="minHeight"
        @input="handleInput"
        @blur="handleBlur"
        class="mgb"
        space="false"
        v-model="infoHtml"
        :disabled="meetingStatus1 != 0 && meetingStatus1 != 9999 && meetingStatus != 3"
        >
      </EditInput>
      <!-- 上传素材 -->
      <div class="upload">
        <div class="title">
          上传素材
          <span>（可不填）</span>
        </div>
        <OptionList
          title="音频"
          border
          gray
          file="audio"
          @uploadComplete="handleAudioChange"
          @fileDelete="handleAudioDelete"
          :disabled="meetingStatus1 != 0 && meetingStatus1 != 9999 && meetingStatus != 3"
          v-model="audio"
          placeholder="上传音频版内容"
        ></OptionList>
        <OptionList
          title="视频"
          file="video"
          border
          gray
          :disabled="meetingStatus1 != 0 && meetingStatus1 != 9999 && meetingStatus != 3"
          @uploadComplete="handleVideoChange"
          @fileDelete="handleVideoDelete"
          v-model="video"
          placeholder="上传视频版内容"
        ></OptionList>
      </div>
      <div
        class="content-setting"
        :class="meetingStatus1 != 0 && meetingStatus1 != 9999 && meetingStatus != 3 ? 'disabled' : ''"
        placeholder="点击添加文稿内容（可不填）"
        v-html="contentHtml"
        @click="handleJump2"
        :disabled="meetingStatus1 != 0 && meetingStatus1 != 9999 && meetingStatus != 3"
      ></div>
      <!-- <div class="start">
        <div class="start-btn" @click="handleAdd" :class="btnStatus ? 'active' : ''">
          发起
        </div>
      </div> -->
      <!-- 开始时间 -->
      <DateTimePicker
        :showPicker="showPicker"
        @cancel="showPicker = false"
        :minDate="minDate"
        type="dateTime"
        @confirm="onConfirm"
      />
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Watch } from 'vue-property-decorator';
import EditInput from '@/components/page/EditInput.vue';
import { jsCallAppParam, filterTimeToDate, getQueryString } from '@/assets/js/common';
import DateTimePicker from '@/components/common/DateTimePicker.vue';
import draggable from 'vuedraggable';

@Component({
  components: {
    OptionList: () => import('@/components/page/OptionList.vue'),
    DateTimePicker,
    draggable,
    EditInput
  }
})
export default class CreateTheme extends Vue {
  // 开始时间选择开关
  showPicker = false;

  // 日期控件的最小时间
  minDate: string | undefined = '';

  // 完成按钮文字颜色
  color = '#B2B2B2';

  // 完成按钮背景颜色
  bgColor = '#F2F2F2';

  // 会议名称
  meetingName = '';

  // 主题会id
  id = '';

  // 选中的议程
  choosedMeeting = {};

  // 选中的议程下标
  choosedMeetingIndex = 0;

  // 提交状态
  submitStatus = false;

  // 近期召开
  tempRecentStart = true;

  // 编辑状态下异步加载组件
  isDataShow = true;

  // 主题会议简介
  infoHtml = '';

  // 主题会议不带格式
  infoText = '';

  // 进度条进度
  width = '';

  // 最大字数限制
  maxLength = 70;

  // 最小字数限制
  minLength = 10;

  // 输入框最小高度
  minHeight = '1.62rem';

  // 文稿设置
  contentHtml = '';

  // 文稿设置不带格式
  contentText = '';

  // 归属学习会
  studyMeetingName = {
    id: null,
    name: ''
  };

  // 音频
  audio = {
    result: '',
    name: ''
  };

  // 视频
  video = {
    result: '',
    name: ''
  };

  // 主题会状态 1 未开始 2 进行中 3 已结束 4 已关闭
  meetingStatus = 1;

  // 所有议程是否结束 9999 表示议程全部结束
  meetingStatus1 = '0';

  // 开始时间
  startTime = '';

  // 传给后台的开始时间数据
  dataTime = '';

  // 议程列表
  list: Array<object> = [
    // {
    //   desc: '1312',
    //   ext: {
    //     tagId: '626544899323331013',
    //     meetingType: 0,
    //     timeUse: '4分钟',
    //     speaker: {
    //       phone: '18771166438',
    //       name: '呵呵嘻嘻嘿嘿',
    //       speakerId: '637009469833740611'
    //     },
    //     time: '3分钟'
    //   },
    //   name: '主题演讲',
    //   id: '663825657431589346',
    //   tagId: '626544899323331013',
    //   status: 3
    // },
    // {
    //   desc: '1312',
    //   ext: {
    //     tagId: '626549294551269829',
    //     meetingType: 1,
    //     timeUse: '3分钟',
    //     time: '3分钟'
    //   },
    //   name: '自由讨论',
    //   id: '663827823168848354',
    //   tagId: '626549294551269829',
    //   status: 3
    // },
    // {
    //   desc: '1312',
    //   ext: {
    //     tagId: '626549294551269829', meetingType: 1, timeUse: '6分钟', time: '2分钟'
    //   },
    //   name: '自由讨论',
    //   id: '663828703234490850',
    //   tagId: '626549294551269829',
    //   status: 2
    // },
    // {
    //   desc: '1312',
    //   ext: {
    //     tagId: '626549294551269829', meetingType: 1, timeUse: '10分钟', time: '0分钟'
    //   },
    //   name: '自由讨论',
    //   id: '663829272854528482',
    //   tagId: '626549294551269829',
    //   status: 1
    // },
    // {
    //   desc: '1312',
    //   ext: {
    //     tagId: '626549294551269829', meetingType: 1, timeUse: '5分钟', time: '0分钟'
    //   },
    //   name: '自由讨论',
    //   id: '663828988581380578',
    //   tagId: '626549294551269829',
    //   status: 1
    // }
  ];

  // 议程id集合
  agendaIds: Array<string> = [];

  created() {
    this.minDate = filterTimeToDate(new Date()).dateTime1;
    this.getMyMeetingList();
    if (getQueryString('id')) {
      this.isDataShow = false;
      this.handleQueryTheme();
    }
  }

  /** 缓存函数
   * @method activated
   */
  activated() {
    window.handleAdd = this.handleAdd;
    window.jumpComfirm = this.jumpComfirm;
    window.handleRefresh = this.handleRefresh;
    // 清除创建学习会标记
    if (localStorage.getItem('isCreate')) localStorage.removeItem('isCreate');
    if (localStorage.getItem('editMeeting')) localStorage.removeItem('editMeeting');
    jsCallAppParam(100, {
      title: '设置主题会议',
      btnText: this.btnText,
      callBack: 'handleAdd',
      color: this.color,
      bgColor: this.bgColor
    });
    this.init();
    // once 在调用前，先解绑，防止事件多次调用  写在deactivated里面不管用
    // 新增议程
    this.$bus.$off('setMeetingData');
    this.$bus.$once('setMeetingData', (res: any) => {
      this.list.push(res);
      this.list.forEach((item: any, index: number) => {
        // property does not exist on type Object 使用 as any
        if (typeof (this.list[index] as any).ext === 'string') {
          (this.list[index] as any).ext = JSON.parse((this.list[index] as any).ext);
        }
      });
    });

    // 编辑议程
    this.$bus.$off('updateMeetingData');
    this.$bus.$once('updateMeetingData', (res: any) => {
      const data = res;
      data.ext = JSON.parse(res.ext);
      this.list.forEach((item: any, index: number) => {
        if (res.id === item.id) {
          this.list.splice(index, 1, data);
        }
      });
    });

    // 设置学习会
    this.$bus.$off('chooseStudyMeeting');
    this.$bus.$on('chooseStudyMeeting', (data: any) => {
      this.studyMeetingName = data;
    });

    // 设置文稿
    this.$bus.$off('setDraftCont');
    this.$bus.$on('setDraftCont', (res: any) => {
      this.contentHtml = res.contentHtml;
      this.contentText = res.contentText;
    });
  }

  /** 初始化
   * @method init
   */
  init() {
    window.goBack = this.goBack;
    window.appGoBack = () => {
      if (!getQueryString('id') && (this.meetingName || this.studyMeetingName.id || this.startTime || this.list.length)) {
        // 调用app提示框
        jsCallAppParam(407, {
          title: '是否要取消发起会议？',
          callBack: 'goBack',
          leftTitle: '否',
          rightTitle: '是'
        });
        return false;
      }
      return true;
    };
  }

  /** app回退
   * @method goBack
   */
  goBack() {
    return true;
  }

  /** 简介内容
   * @method handleInput
   * @param obj
   */
  handleInput(e: any) {
    this.infoHtml = e.innerHTML;
    this.infoText = e.innerText;
  }

  /** 失去焦点事件
   * @method handleBlur
   */
  handleBlur() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
  }

  /** 拖动元素不能拖到不可拖拽元素后面
   * @method onMove
   * @param evt
   */
  onMove(evt: any) {
    if (evt.related.classList && evt.related.classList.length) return !evt.related.classList.value.includes('item');
    return true;
  }

  /** 获取进度条进度
   * @method getWidth
   * @param item
   */
  getWidth(item: any) {
    // 转换成小数
    const point = parseInt(item.time, 0) / parseInt(item.ext.timeUse, 0);
    // 转换成百分比
    let str = (Math.floor(point * 100) >= 100 ? 100 : Math.floor(point * 100)).toString();
    str += '%';
    return str;
  }

  /** 近期召开按钮切换
   * @method switchChange
   */
  switchChange(val: boolean) {
    this.tempRecentStart = val;
  }

  /** 跳转到文稿编辑
   * @method handleJump2
   */
  handleJump2() {
    if (this.meetingStatus1 !== '0' && this.meetingStatus1 !== '9999' && this.meetingStatus !== 3) return;
    this.$router.push({
      name: 'EditDraft',
      params: {
        content: this.contentHtml,
        contentText: this.contentText
      }
    });
  }

  /** 开始时间
   * @method handleChooseTime
   */
  handleChooseTime() {
    // 查询主题状态下不让编辑
    if (getQueryString('id') && this.meetingStatus !== 1) return;
    this.showPicker = true;
  }

  /** 根据id查询主题详情
   * @method handleQueryTheme
   * @param {Number} flag 是否只刷新议程数据
   */
  handleQueryTheme(flag?: number) {
    this.$http
      .get(`/mission/app/mission/queryThemeInfo/${getQueryString('id')}`)
      .then((res: any) => {
        if (res) {
          this.isDataShow = true;
          if (!flag) {
            this.meetingName = res.themeName;
            this.studyMeetingName = {
              id: res.missionId,
              name: res.missionName
            };
            const data = JSON.parse(res.ext);
            // 音视频如果存在，格式化其名字
            this.video = data.video;
            this.audio = data.audio;
            if (this.video) {
              this.video.name = this.nameTransform(this.video.name);
            }
            if (this.audio) {
              this.audio.name = this.nameTransform(this.audio.name);
            }
            this.infoHtml = res.desc;
            this.infoText = res.content;
            this.contentHtml = data.content.contentHtml;
            this.contentText = data.content.contentText;
            this.dataTime = res.startTime;
            this.id = res.id;
            this.startTime = this.timeTranform(res.startTime);
          }
          this.meetingStatus = res.status;
          this.meetingStatus1 = res.ingAgendaId;
          if (res.agendaInfos && res.agendaInfos.length) {
            this.list = res.agendaInfos;
            /**
             * 议程中的status, 1 未开始, 2 进行中, 3 进行后
             */
            this.list.forEach((item: any, index: number) => {
              if (res.ingAgendaId === item.id) { // 有进行的议程
                (this.list[index] as any).status = this.meetingStatus === 3 || this.meetingStatus1 === '9999' ? 3 : 2;
                (this.list[index] as any).time = `${Math.floor(res.agendaLength / 60)}分钟`;
                for (let i = 0; i < index; i += 1) { // 进行议程之前的就是会后议程
                  (this.list[i] as any).status = 3;
                  (this.list[i] as any).time = (this.list[i] as any).ext.timeUse;
                }
              } else if (this.meetingStatus !== 3 && this.meetingStatus1 !== '9999') { // 没有进行的议程
                (this.list[index] as any).status = 1;
                (this.list[index] as any).time = 0;
              } else { // 议程进行时结束了会议
                (this.list[index] as any).status = 3;
                (this.list[index] as any).time = 0;
              }
              if (typeof item.ext === 'string') {
                (this.list[index] as any).ext = JSON.parse(item.ext);
              }
            });
            console.log(this.list);
            // 根据seq从小到大排序
            this.list = this.list.sort(this.compare('seq'));
          }
        }
      });
  }

  /** 获取学习会列表
   * @method getMyMeetingList
   */
  getMyMeetingList() {
    this.$http.post('/mission/app/mission/getMeetingList').then((res: any) => {
      if (res.MeetingNames) {
        [this.studyMeetingName] = res.MeetingNames;
      }
    });
  }

  /** 时间格式转换
   * @method timeTranform
   * @param {string} date 时间字符串 2020-03-25 18:00:00
   * @return {string} 时间字符串 03月25日 周三 18:00
   */
  timeTranform(date: string) {
    const dateCommon = date.replace(/-/g, '/');
    const date1 = dateCommon.split(' ')[0];
    const date2 = dateCommon.split(' ')[1];
    const val = date1.split('/');
    const val1 = date2.split(':');
    const weekday = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];
    const day = new Date(dateCommon).getDay();
    const week = weekday[day];
    return `${val[1]}月${val[2]}日 ${week} ${val1[0]}:${val1[1]}`;
  }

  /** 选择学习会跳转
   * @method handleChooseMeeting
   */
  handleChooseMeeting() {
    // 会中不支持编辑
    if (this.meetingStatus1 !== '0' && this.meetingStatus1 !== '9999' && this.meetingStatus !== 3) return;
    this.$router.push({
      path: '/myStudyMeeting',
      query: {
        id: this.studyMeetingName.id
      }
    });
  }

  /** 添加议程
   * @method handleAddMeeting
   */
  handleAddMeeting() {
    this.$router.push({
      name: 'SettingMeeting',
      params: {
        flag: '1'
      }
    });
  }

  /** 日期选择
   * @method onConfirm
   * @param {any} value 对象
   */
  onConfirm(value: any) {
    this.startTime = value.showTime;
    this.dataTime = value.dataTime;
  }

  /** 删除议程
   * @method handleDeleteMeeting
   * @param {any} item 对象
   * @param {Number} index 索引
   */
  handleDeleteMeeting(item: any, index: number) {
    // 编辑状态下，会中，会后不让删除
    if (getQueryString('id') && (item.status === 2 || item.status === 3)) return;
    let id = 0;
    this.agendaIds.forEach((ids: string, index1: number) => {
      if (ids === item.id) {
        id = index1;
      }
    });
    this.$http.delete(`/mission/app/mission/delAgendaById/${item.id}`).then(() => {
      this.agendaIds.splice(id, 1);
      this.list.splice(id, 1);
      // 通知app删除议程了
      /** 412 通知app议程变动了
       * @type 1 跳过议程 2 删除议程 3 编辑和新增议程
       * @value 可选参数
       */
      jsCallAppParam(412, {
        type: 2,
        value: item.id
      });
    });
  }

  /** 会后点击toast
   * @method handleDisabled
   * @param item
   */
  handleDisabled(item: any, e: Event) {
    if (getQueryString('id') && item.status === 3) {
      e.preventDefault();
      this.$xxhToast('会议结束后议程不支持修改');
    }
  }

  /** 跳转至议程
   * @method handleJump
   * @param {any} item 对象
   */
  handleJump(item: any) {
    if (getQueryString('id') && item.status === 3) return;
    localStorage.setItem('editMeeting', '1');
    const data = Object.assign(item, {});
    data.setDate = item.setDate;
    this.$router.push({
      name: 'SettingMeeting',
      params: {
        params: data
      }
    });
  }

  /** 跳过议程
   * @method handleJumpMeeting
   * @param index
   */
  handleJumpMeeting(item: any, index: number) {
    this.choosedMeeting = item;
    console.log(this.choosedMeeting);
    this.choosedMeetingIndex = index;
    const title = index === this.list.length - 1 ? '跳过最后一个议程将进入会后自由讨论环节，确定跳过吗' : '跳过该议程将直接开始下一个议程，确定跳过吗';
    // todo 弹出app提示框
    jsCallAppParam(407, {
      title,
      callBack: 'jumpComfirm',
      leftTitle: '取消',
      rightTitle: '确定'
    });
  }

  /** 跳过议程确认
   * @method jumpComfirm
   */
  jumpComfirm() {
    // 当前置灰
    const data: any = Object.assign(this.choosedMeeting, {});
    data.status = 3;
    this.$set(this.list, this.choosedMeetingIndex, data);
    if (this.choosedMeetingIndex !== this.list.length - 1) { // 不是最后一个,下一个开始
      const nextData: any = Object.assign(this.list[this.choosedMeetingIndex + 1], {});
      nextData.status = 2;
      this.$set(this.list, (this.choosedMeetingIndex + 1), nextData);
    } else {
      // 如果是最后一个,议程全部结束，隐藏新增按钮
      this.meetingStatus1 = '9999';
    }
    // 通知app跳过议程了
    jsCallAppParam(412, {
      type: 1,
      value: (this.choosedMeeting as any).id
    });
  }

  /** 刷新议程数据
   * @method handleRefresh
   */
  handleRefresh() {
    this.handleQueryTheme(1);
  }

  /** 上传音频
   * @method handleAudioChange
   * @param {any} res
   */
  handleAudioChange(res: any) {
    this.audio = res;
  }

  /** 删除音频
   * @method handleAudioDelete
   */
  handleAudioDelete() {
    this.audio = {
      result: '',
      name: ''
    };
  }

  /** 上传视频
   * @method handleVideoChange
   * @param {any} res
   */
  handleVideoChange(res: any) {
    this.video = res;
  }

  /** 删除视频
   * @method handleVideoDelete
   */
  handleVideoDelete() {
    this.video = {
      result: '',
      name: ''
    };
  }

  /** 发起主题会议
   * @method handleAdd
   */
  handleAdd() {
    if (this.btnStatus) {
      if (this.submitStatus) return;
      this.submitStatus = true;
      if (this.infoText.length < this.minLength) {
        this.submitStatus = false;
        this.$xxhToast('会议简介请输入10-70字');
        return;
      }
      if (!getQueryString('id') && this.status) {
        this.submitStatus = false;
        this.$xxhToast('请至少提前5分钟创建会议');
        return;
      }
      const ext = {
        // 视频
        video: this.video,
        // 音频
        audio: this.audio,
        // 文稿内容
        content: {
          contentHtml: this.contentHtml, // 带格式
          contentText: this.contentText // 不带格式
        }
      };
      const params: any = {
        desc: this.infoHtml,
        content: this.infoText,
        agendaIds: this.agendaIds,
        name: this.meetingName,
        pid: this.studyMeetingName.id,
        startTime: this.dataTime,
        ext: JSON.stringify(ext)
      };
      if (getQueryString('id')) {
        params.id = this.id;
        // console.log('getModifyStatus----', params);
        // 后台判断是否有内容改动
        // this.$http.post('/mission/app/mission/getModifyStatus', params).then((res: any) => {
        //   this.submitStatus = false;
        //   console.log(res);
        //   if (res) {
        //     params.agendaIds = this.agendaIds;
        //     console.log('editTheme----', params);
        //   }
        // });
        // 提交编辑
        console.log('editTheme----', params);
        this.$http.post('/mission/app/mission/editTheme', params).then(() => {
          this.submitStatus = false;
          // 通知app议程改动了
          jsCallAppParam(412, {
            type: 3
          });
          // 跳到app首页
          jsCallAppParam(402, {});
        })
          .catch((err: any) => {
            this.$xxhToast({
              text: err.msg
            });
            this.submitStatus = false;
          });
      } else {
        this.$http
          .post('/mission/app/mission/createTheme', params)
          .then((res: string) => {
            this.submitStatus = false;
            if (res) {
              // 跳到app首页
              jsCallAppParam(402, {});
            }
          })
          .catch((err: any) => {
            this.$xxhToast({
              text: err.msg
            });
            this.submitStatus = false;
          });
      }
    }
  }

  /** 音视频名字过长转换
   * @method nameTransform
   * @param {string} name 视频名
   * @return {string} 视频名
   */
  nameTransform(name: string) {
    if (!name) return '';
    const arr = name.split(' ');
    const nameStr = arr[0].substring(0, arr[0].lastIndexOf('.'));
    const nameStr1 = arr[0].substring(arr[0].lastIndexOf('.'), arr[0].length);
    let str = '';
    if (nameStr.length > 6) {
      str = `${nameStr.substring(0, 6)}... ${nameStr1} ${arr[1]}`;
    } else {
      str = `${name} ${arr[1]}`;
    }
    return str;
  }

  /** 排序函数
   * @method compare
   * @param {string} property 排序字段
   */
  compare(property: string) {
    return (a: any, b: any) => {
      const value1 = a[property];
      const value2 = b[property];
      return value1 - value2;
    };
  }

  /**
   * 开始时间是否可编辑
   */
  get isEditable() {
    if (getQueryString('id')) {
      return this.meetingStatus !== 1;
    }
    return false;
  }

  /**
   * 计算属性 近期召开开关
   */
  get recentStart() {
    if (getQueryString('id')) {
      return this.meetingStatus === 1 && this.tempRecentStart;
    }
    return this.tempRecentStart;
  }

  /**
   * 计算属性 按钮状态
   */
  get btnStatus() {
    return !!(
      this.meetingName
      && this.infoText
      && this.studyMeetingName.id
      && this.list.length
      && this.startTime
    );
  }

  /**
   * 计算属性 头部标题
   */
  get btnText() {
    return getQueryString('id') ? '完成' : '发起';
  }

  /** 计算属性 主题会创建时间判断
   * @method status
   * @return boolean
   */
  get status() {
    const timeStr = this.dataTime.replace(/-/g, '/');
    const nowTime = new Date().getTime() + 5 * 60 * 1000;
    const chooseTime = new Date(timeStr).getTime();
    return nowTime - chooseTime > 0;
  }

  /**
   * 监听议程列表的改变来动态改变议程id集合，拖拽排序
   */
  @Watch('list', { deep: true })
  listChange(val: any) {
    this.agendaIds = [];
    val.forEach((item: any) => {
      this.agendaIds.push(item.id);
    });
  }

  /**
   * 监听头部返回按钮状态
   */
  @Watch('btnStatus')
  statusChange(val: boolean) {
    if (val) {
      this.color = '#ffffff';
      this.bgColor = '#2CC07C';
    } else {
      this.color = '#B2B2B2';
      this.bgColor = '#F2F2F2';
    }
    jsCallAppParam(100, {
      title: '设置主题会议',
      btnText: this.btnText,
      backText: '取消',
      color: this.color,
      bgColor: this.bgColor,
      callBack: 'handleAdd'
    });
  }
}
</script>

<style lang="scss" scoped>
.create-theme {
  width: 100%;
  background-color: $bg;
  padding-bottom: 1rem;
  // 基础设置
  .basic-setting,
  .content-setting-title {
    background-color: $bg;
    padding-left: 0.3rem;
    height: 1rem;
    text-align: left;
    line-height: 1rem;
    font-size: 0.3rem;
    color: $text2;
    font-family: PingFangSC-Semibold;
  }
  .basic-setting-box {
    background-color: #fff;
  }
  // 议程设置
  .meeting-setting {
    padding: 0.32rem 0.3rem 0.4rem;
    background-color: #fff;
    .content {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 0.32rem;
      .left,
      .right {
        width: 0.94rem;
        height: 0.94rem;
        background-color: $bg;
        display: flex;
        justify-content: center;
        align-items: center;
        border-radius: 0.08rem;
        i {
          font-size: 0.46rem;
          color: $text3;
        }
      }
      .left {
        margin-right: 0.16rem;
        display: flex;
        justify-content: center;
        align-items: center;
        span {
          color: $first;
          font-size: 0.34rem;
        }
      }
      .center {
        background-color: $bg;
        flex: 1;
        height: 0.94rem;
        position: relative;
        border-radius: 0.08rem;
        .progress-box {
          position: absolute;
          height: 100%;
          transition: width 0.1s linear;
          background-color: $first;
          // border-radius: 0.08rem;
          border-top-left-radius: 0.08rem;
          border-bottom-left-radius: 0.08rem;
        }
        .progress {
          position: absolute;
          width: 100%;
          border-radius: 0.08rem;
          .progress-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 0.94rem;
            padding: 0 0.2rem;
            border-radius: 0.08rem;
            span {
              font-size: 0.34rem;
              height: 100%;
              line-height: 0.94rem;
              &:first-child {
                color: $text1;
              }
              &:last-child {
                color: $text2;
                display: flex;
                justify-content: center;
                align-items: center;
                i {
                  margin-left: 0.2rem;
                }
              }
            }
          }
        }
      }
      .right {
        margin-left: 0.16rem;
      }
    }
    .add-meeting {
      margin: 0.4rem auto 0;
      width: 3rem;
      height: 0.64rem;
      border: 1px solid $text1;
      border-radius: 0.32rem;
      box-sizing: border-box;
      color: $text1;
      font-size: 0.34rem;
      font-weight: 500;
      display: flex;
      justify-content: center;
      align-items: center;
    }
  }
  // 内容设置
  .content-setting {
    width: 100%;
    padding: 0.3rem;
    box-sizing: border-box;
    min-height: 1.62rem;
    background-color: #fff;
    word-break: break-all;
    text-align: left;
    margin-bottom: 0.16rem;
    color: $text2;
    font-size: 0.34rem;
    font-family: PingFangSC-Regular;
    outline: none;
    &:empty:before {
      content: attr(placeholder);
      opacity: 0.5;
      color: #333;
      font-family: PingFangSC-Regular;
      font-size: 0.34rem;
      line-height: 0.34rem;
    }
  }
  // 上传素材
  .upload {
    margin-bottom: 0.16rem;
    .title {
      padding: 0.32rem 0 0 0.3rem;
      background-color: #fff;
      color: #000;
      font-size: 0.34rem;
      line-height: 0.34rem;
      font-weight: 500;
      text-align: left;
      span {
        color: $text2;
      }
    }
    .border-box {
      > span {
        color: $text3;
      }
    }
  }
  // 发起按钮
  .start {
    padding: 0 0.3rem 2rem;
    box-sizing: border-box;
    .start-btn {
      width: 100%;
      background-color: $btnBg;
      height: 0.94rem;
      margin-top: 0.4rem;
      border-radius: 0.47rem;
      display: flex;
      justify-content: center;
      align-items: center;
      color: $text3;
      font-size: 0.34rem;
    }
    .active {
      background-color: $first;
      color: #fff;
    }
  }
  // 背景置灰
  .disabled {
    opacity: 0.5;
  }
  .mgb {
    margin-bottom: .16rem;
  }
}
</style>
