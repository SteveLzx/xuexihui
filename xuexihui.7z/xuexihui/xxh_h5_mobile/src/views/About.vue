<template>
  <div class="about">
    <div class="btn1">强调按钮</div>
    <br>
    <div class="btn2">弱化按钮</div>
    <br>
    <div class="btn3">失效按钮</div>
    <br>
    <div class="btn4">警示按钮</div>
    <br>
    <div class="btn1-s">完成</div>
    <div class="btn2-s">完成</div>
    <div class="btn3-s" @click="handleClick1">完成</div>
    <div class="btn4-s" @click="handleClick">完成</div>
    <br>
    <OptionList title="我是1标题" :border="selectValue" switch value='false'></OptionList>
    <OptionList title="我是标题" border select
                @click="changeS" :selectValue='selectValue'></OptionList>
    <OptionList title="我是标题" border select
                @click="changeS" :selectValue='!selectValue'></OptionList>
    <OptionList title="我是标题" border input placeholder="请输入"
    v-model='inputValue' @input="input"></OptionList>
    <OptionList title="我是标题" border disabled choose value='false'
                @click="showPic" chooseValue="五项以上选择器"></OptionList>
    <PopupPicker :showPicker="showPicker" @confirm="onConfirm"
                 :columns="columns" default-index="3" @cancel="showPicker = false"/>
    <OptionList title="我是标题" disabled border choose value='false'
                @click="showPic2" chooseValue="五项以下选择器"></OptionList>
    <ActionSheet :showPicker="showPicker2" @cancel="showPicker2 = false"
                 :columns="columns"
                 @confirm="onConfirm2"/>
    <OptionList title="我是标题" border choose
                @click="showPic3" chooseValue="选择日期"></OptionList>
    <DateTimePicker :showPicker="showPicker3" @cancel="showPicker3 = false"
                    :minDate="minDate"
                    type="dateTime"
                    :maxDate="maxDate" default="2020-02-23 20:00"
                    @confirm="onConfirm3"/>
  </div>
</template>
<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import OptionList from '@/components/page/OptionList.vue';
import PopupPicker from '@/components/common/PopupPicker.vue';
import ActionSheet from '@/components/common/ActionSheet.vue';
import DateTimePicker from '@/components/common/DateTimePicker.vue';

@Component({
  components: {
    OptionList,
    PopupPicker,
    ActionSheet,
    DateTimePicker
  }
})
export default class About extends Vue {
  inputValue = '哈哈哈哈哈啊哈';

  selectValue = false;

  showPicker = false;

  showPicker2 = false;

  showPicker3 = false;

  minDate = '2020-02-01';

  maxDate = '2020-03-02';

  columns = ['杭州', '宁波', '温州', '嘉兴', '湖州'];

  created() {
    // this.$loading.show();
  }

  handleClick1() {
    this.$xxhToast({ text: '提示下1', timeout: 3 });
  }

  handleClick() {
    this.$xxhToast({ text: '提示下', timeout: 3 });
  }

  changeS() {
    this.selectValue = !this.selectValue;
    console.log(this.selectValue);
  }

  showPic() {
    this.showPicker = true;
  }

  showPic2() {
    this.showPicker2 = true;
  }

  showPic3() {
    this.showPicker3 = true;
  }

  onConfirm(data: any) {
    console.log(`当前值：${data.value}, 当前索引：${data.index}`);
  }

  onConfirm2(data: any) {
    console.log(data);
  }

  onConfirm3(data: any) {
    console.log(data);
  }

  onCancel() {
    this.showPicker = false;
  }

  input() {
    console.log(this.inputValue);
  }
}
</script>
<style lang="scss" scoped>

</style>
