<template>
  <div class="add-study-meeting">
    <!-- 测试 -->
    <!-- <OptionList title="测试" choose @click="handleComplete" chooseValue="完成"></OptionList> -->
    <div ref="addStudyMeeting">
      <OptionList
        title="学习会名称"
        maxlength="20"
        v-model="meetingName"
        input
        placeholder="输入学习会名称"
      ></OptionList>
      <div class="setting-title">设置介绍内容</div>
      <div class="edit" v-html="content" @click="handleEdit"></div>

    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Watch } from 'vue-property-decorator';
import OptionList from '@/components/page/OptionList.vue';
import { jsCallAppParam, getQueryString } from '@/assets/js/common';

@Component({
  components: { OptionList }
})
export default class CreateTheme extends Vue {
  // 学习会名称
  meetingName = '';

  // 学习会id
  id = '';

  // 改变前的学习会名称
  tempMeetingName = '';

  // 带格式文稿内容
  content = '';

  // 不带格式文本
  contentText = '';

  // 改变前的文稿内容
  tempContent = '';

  // 完成按钮文字颜色
  color = '#B2B2B2';

  // 完成按钮背景颜色
  bgColor = '#F2F2F2';

  created() {
    window.handleComplete3 = this.handleComplete;
    const id = getQueryString('id');
    // 根据学习会id查询学习会详情
    if (id) {
      this.getMeetingDetail(id);
    }
  }

  /** 缓存函数
   * @method activated
   */
  activated() {
    (this.$refs.addStudyMeeting as any).scrollTop = 0;
    window.appGoBack = () => {
      // 清除创建学习会标记
      if (localStorage.getItem('isCreate')) localStorage.removeItem('isCreate');
      this.$router.go(-1);
      return false;
    };
    jsCallAppParam(100, {
      title: '设置学习会',
      btnText: '完成',
      backText: '取消',
      color: this.color,
      bgColor: this.bgColor,
      callBack: 'handleComplete3'
    });
    // 设置文稿
    this.$bus.$off('setDraft');
    this.$bus.$on('setDraft', (res: any) => {
      this.content = res.contentHtml;
      this.contentText = res.contentText;
    });
    // 是否是新建学习会
    if (this.$route.params.flag) {
      this.content = '';
      this.contentText = '';
      this.meetingName = '';
    }
  }

  /** 根据学习会id查询学习会详情
   * @method getMeetingDetail
   * @param {String} id
   */
  getMeetingDetail(id: string) {
    this.$http.get(`/mission/app/mission/getMeetingDetail/${id}`).then((res: any) => {
      this.meetingName = res.meetingName;
      this.id = res.meetingId;
      // 储存学习会名称
      this.tempMeetingName = res.meetingName;
      this.content = res.desc;
      this.contentText = res.content;
      // 储存内容
      this.tempContent = res.desc;
    });
  }

  /** 完成按钮
   * @method handleComplete
   */
  handleComplete() {
    if (!this.btnStatus) return;
    const params: any = {
      desc: this.content,
      name: this.meetingName,
      content: this.contentText
    };
    const url = getQueryString('id') ? '/mission/app/mission/editMeeting' : '/mission/app/mission/createMeeting';
    if (getQueryString('id')) params.id = this.id;
    this.$http.post(url, params).then((res: any) => {
      setTimeout(() => {
        this.$router.go(-1);
      }, 500);
    });
  }

  /** 文稿编辑
   * @method handleEdit
   */
  handleEdit() {
    this.$router.push({
      name: 'EditDraft',
      params: {
        content: this.content,
        contentText: this.contentText,
        flag: '2'
      }
    });
  }

  /** 完成按钮状态
   * @method btnStatus
   * @return boolean
   */
  get btnStatus() {
    if (getQueryString('id')) {
      return (this.meetingName !== this.tempMeetingName) || (this.content !== this.tempContent);
    }
    return !!(this.meetingName && this.content);
  }

  /**
   * 监听完成按钮状态，动态改变app头部右侧完成按钮显示
   */
  @Watch('btnStatus')
  statusChange(val: boolean) {
    console.log(val);
    if (val) {
      this.color = '#ffffff';
      this.bgColor = '#2CC07C';
    } else {
      this.color = '#B2B2B2';
      this.bgColor = '#F2F2F2';
    }
    jsCallAppParam(100, {
      title: '新建学习会',
      btnText: '完成',
      backText: '取消',
      color: this.color,
      bgColor: this.bgColor,
      callBack: 'handleComplete3'
    });
  }
}
</script>

<style lang="scss" scoped>
.add-study-meeting {
  width: 100%;
  height: 100%;
  background-color: #f7f7f7;
  padding-top: 0.16rem;
  .setting-title {
    padding: 0.4rem 0 0.3rem 0.4rem;
    color: #7f7f7f;
    font-size: 0.3rem;
    line-height: 0.3rem;
    text-align: left;
    font-weight: 500;
  }
  .edit {
    width: 100%;
    min-height: 1.62rem;
    padding: 0.3rem 0.3rem;
    font-size: 0.34rem;
    color: #7f7f7f;
    text-align: left;
    background-color: #fff;
    box-sizing: border-box;
    word-break: break-all;
    &:empty::before {
      content: "点击编辑文稿内容";
      color: #333;
      font-size: 0.34rem;
      line-height: 0.34rem;
      opacity: 0.5;
    }
  }
}
</style>
