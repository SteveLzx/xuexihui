<template>
  <div class="name-setting">
    <div class="name-box">
      <input
        class="name-input"
        type="text"
        maxlength="20"
        v-model.trim="name"
      />
      <i class="iconfont close" v-show="name" @click="closeFunc($event)">&#xe61a;</i>
    </div>
  </div>
</template>
<script lang='ts'>
import { Component, Vue, Watch } from 'vue-property-decorator';
import { State } from 'vuex-class';
import { jsCallAppParam } from '@/assets/js/common';

@Component
export default class NameSetting extends Vue {
  @State userInfo: any;

  private name = '';

  created() {
    window.nameSettingSuccess = this.submit;
    window.appGoBack = () => {
      this.$router.go(-1);
      return false;
    };
    jsCallAppParam(100, {
      title: '设置名字',
      btnText: '完成',
      backText: '取消',
      color: '#7F7F7F',
      bgColor: '#f2f2f2',
      callBack: ''
    });
    this.name = this.userInfo.userInfoData.name;
  }

  closeFunc() {
    this.name = '';
  }

  /**
   * 提交
   */
  submit() {
    this.$http
      .post('/user/app/editUserInfo', { isEdit: 1, name: this.name })
      .then((res: any) => {
        jsCallAppParam(405, {
          token: res.userToken
        });
        jsCallAppParam(409, {
          name: this.name,
          callBack: 'appRefresh'
        });
        this.$xxhToast({ text: '保存成功', timeout: 1 });
        setTimeout(() => {
          this.$router.go(-1);
        }, 1000);
      });
  }

  @Watch('name')
  getName(newVal: string, oldVal: string) {
    if (this.userInfo.userInfoData.name !== newVal && newVal.length) {
      const ret = /[\u4E00-\u9FA5A-z]/g;
      if (!ret.test(newVal)) {
        this.name = oldVal;
      }
      jsCallAppParam(100, {
        title: '设置名字',
        btnText: '完成',
        backText: '取消',
        color: '#ffffff',
        bgColor: '#2CC07C',
        callBack: 'nameSettingSuccess'
      });
    } else {
      jsCallAppParam(100, {
        title: '设置名字',
        btnText: '完成',
        backText: '取消',
        color: '#7F7F7F',
        bgColor: '#f2f2f2',
        callBack: ''
      });
    }
  }
}
</script>
<style lang="scss" scoped>
.name-setting {
  background-color: $bg;
  height: 100%;
  padding-top: .14rem;
}
.name-box {
  display: flex;
  align-items: center;
  width: 100%;
  height: 1.12rem;
  background-color: #ffffff;
}
.name-input {
  width: 100%;
  height: 0.48rem;
  padding: 0 0.3rem;
  color: $text1;
  font-size: 0.34rem;
  text-align: left;
  font-family: PingFangSC-Regular;
  border: 0;
}
.iconfont.close {
  margin-right: 0.4rem;
  font-size: 0.4rem;
  color: rgba(0, 0, 0, 0.3);
}
</style>
