<template>
  <div class="edit-profile">
    <div class="head-portrait" @click="appUploadImg">
      <span class="lable">头像</span>
      <div class="img-box">
        <div class="upload-img">
            <img class="head-url" :src="userInfo.userInfoData.avatar" @error="imgerrorfun"/>
        </div>
        <i class="iconfont right">&#xe61f;</i>
      </div>
    </div>
    <div class="marginTop">
      <OptionList
        title="姓名"
        border
        choose
        :chooseValue="userInfo.userInfoData.name"
        @click="$router.push({name: 'NameSetting'})"></OptionList>
      <OptionList
        title="性别"
        choose
        :chooseValue="getSex"
        @click="$router.push({name: 'GenderSetting'})"
      ></OptionList>
    </div>
    <div class="marginTop mobile-box">
      <OptionList
        title="手机号"
        :iconValue='false'
        choose
        :chooseValue="userInfo.userInfoData.mobile"
      ></OptionList>
    </div>
  </div>
</template>
<script lang='ts'>
import { Component, Vue } from 'vue-property-decorator';
import { namespace, State } from 'vuex-class';
import { jsCallAppParam } from '@/assets/js/common';
import OptionList from '@/components/page/OptionList.vue';

// 表示连接的是userInfo module。
const userInfo = namespace('userInfo');

@Component({
  components: { OptionList }
})
export default class EditProfile extends Vue {
  @State userInfo: any;

  @userInfo.Action getUserInfoData: any;

  created() {
    window.appGoBack = () => true;
    const { mobile } = this.$route.query;
    window.appRefresh = () => {
      this.getUserInfoData(mobile);
    };
    jsCallAppParam(100, {
      title: '个人资料'
    });
    /**
      * 根据手机号获取用户信息
      *  */
    this.getUserInfoData(mobile);
  }

  appUploadImg() {
    window.appRefresh = () => {
      this.getUserInfoData(this.$route.query.mobile);
    };

    jsCallAppParam(404, {
      callBack: 'appRefresh'
    });
  }

  imgerrorfun(event: any) {
    const img = event.srcElement;
    img.src = this.userInfo.userInfoData.avatar;
    img.onerror = null;
  }

  // 计算性别
  get getSex() {
    const arr = ['未知', '男', '女'];
    return arr[this.userInfo.userInfoData.sex];
  }
}
</script>
<style lang="scss" scoped>
.edit-profile {
  background-color: $bg;
  height: 100%;
  padding-top: 0.16rem;
}
.marginTop {
  margin-top: 0.16rem;
}
.head-portrait {
  height: 1.68rem;
  padding-left: 0.3rem;
  background-color: rgba(255, 255, 255, 1);
  display: flex;
  justify-content: space-between;
  align-items: center;
  .lable {
    color: rgba(0, 0, 0, 1);
    font-size: 0.34rem;
    text-align: center;
    font-family: PingFangSC-Regular;
  }
  .img-box {
    padding-right: 0.3rem;
    text-align: left;
    color: #000;
    font-size: 0.34rem;
    line-height: 1.68rem;
    position: relative;
    display: flex;
    align-items: center;
    .iconfont.right {
      position: relative;
      top: 0.01rem;
      color: $text3;
      float: right;
      margin-left: 0.1rem;
    }
    .upload-img {
      width: 1.28rem;
      height: 1.28rem;
      border-radius: 50%;
      position: relative;
      display: flex;
    }
    .name {
      display: block;
      width: 1.28rem;
      height: 1.28rem;
      border-radius: 50%;
      background-color: $first;
      color: rgba(255, 255, 255, 1);
      font-size: 0.36rem;
      text-align: center;
      line-height: 1.28rem;
      font-family: PingFangSC-Semibold;
    }
    .head-url {
      display: block;
      width: 1.28rem;
      height: 1.28rem;
      border-radius: 50%;
    }
    .upload-input {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      opacity: 0;
    }
  }
}
</style>
