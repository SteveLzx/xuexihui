<template>
  <div class="gender-setting">
    <OptionList
      title="男"
      border
      select
      :selectValue='genderType === 1'
      @click.stop="changeGender(1)"
    ></OptionList>
    <OptionList
      title="女"
      border
      select
      :selectValue='genderType === 2'
      @click.stop="changeGender(2)"
    ></OptionList>
  </div>
</template>
<script lang='ts'>
import { Component, Vue, Watch } from 'vue-property-decorator';
import { State } from 'vuex-class';
import { jsCallAppParam } from '@/assets/js/common';
import OptionList from '@/components/page/OptionList.vue';

@Component({
  components: { OptionList }
})
export default class GenderSetting extends Vue {
  @State userInfo: any;

  private genderType = 0;

  created() {
    window.genderSettingSuccess = this.submit;
    window.appGoBack = () => {
      this.$router.go(-1);
      return false;
    };
    jsCallAppParam(100, {
      title: '设置性别',
      btnText: '完成',
      backText: '取消',
      color: '#7F7F7F',
      bgColor: '#f2f2f2',
      callBack: ''
    });
    this.genderType = this.userInfo.userInfoData.sex;
  }

  changeGender(num: number) {
    this.genderType = num;
  }

  /**
   * 提交
   */
  submit() {
    this.$http.post('/user/app/editUserInfo', { isEdit: 1, sex: this.genderType }).then((res: any) => {
      jsCallAppParam(405, {
        token: res.userToken
      });
      this.$xxhToast({ text: '保存成功', timeout: 1 });
      setTimeout(() => {
        this.$router.go(-1);
      }, 1000);
    });
  }

  @Watch('genderType')
  getGenderType(newVal: number) {
    if (this.userInfo.userInfoData.sex !== newVal) {
      jsCallAppParam(100, {
        title: '设置性别',
        btnText: '完成',
        backText: '取消',
        color: '#ffffff',
        bgColor: '#2CC07C',
        callBack: 'genderSettingSuccess'
      });
    } else {
      jsCallAppParam(100, {
        title: '设置性别',
        btnText: '完成',
        backText: '取消',
        color: '#7F7F7F',
        bgColor: '#f2f2f2',
        callBack: ''
      });
    }
  }
}
</script>
<style lang="scss" scoped>
.gender-setting{
  background-color: $bg;
  height: 100%;
  padding-top: 0.14rem;
}
</style>
