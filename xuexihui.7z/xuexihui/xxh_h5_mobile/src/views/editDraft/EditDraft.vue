<template>
  <div class='edit-draft'>
    <!-- 测试 -->
    <!-- <OptionList title='测试' choose @click='handleComplete' chooseValue='完成'></OptionList> -->

    <EditInput
      ref="editInput"
      :maxLength="maxLength"
      :isOpenUploadImg="isOpenUploadImg"
      @input="handleInput"
      v-model="content"
      space="true"
      >
    </EditInput>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Watch } from 'vue-property-decorator';
import { jsCallAppParam } from '@/assets/js/common';
import OptionList from '@/components/page/OptionList.vue';
import EditInput from '@/components/page/EditInput.vue';

interface ObjType {
  [key: string]: {
    maxLength: number;
    text: string;
  };
}

@Component({
  components: { OptionList, EditInput }
})
export default class EditDraft extends Vue {
  // 完成按钮文字颜色
  color = '#B2B2B2';

  // 是否开启上传图片入口
  isOpenUploadImg = false;

  // 完成按钮背景颜色
  bgColor = '#F2F2F2';

  // 文稿内容，用于传递
  content = '';

  // 纯文本
  contentText = '';

  // 临时纯文本
  tempContentText = '';

  // 最大长度限制
  maxLength = 500;

  created() {
    window.handleComplete2 = this.handleComplete;
    window.goBack = this.goBack;
    this.content = this.$route.params.content;
    this.contentText = this.$route.params.contentText;
    this.tempContentText = this.$route.params.contentText;
    this.isOpenUploadImg = !this.$route.params.flag;
    jsCallAppParam(100, {
      title: '设置文稿',
      btnText: '完成',
      backText: '取消',
      color: this.color,
      bgColor: this.bgColor,
      callBack: 'handleComplete2'
    });
    window.appGoBack = () => {
      if (this.content) {
        jsCallAppParam(407, {
          title: '退出后编辑内容将不被保存，确定要退出吗？',
          callBack: 'goBack',
          leftTitle: '取消',
          rightTitle: '确定'
        });
      } else {
        this.$router.go(-1);
      }
      return false;
    };
    this.maxLength = this.getTools(this.$route.params.flag).maxLength;
  }

  /** 获取最大字数限制
   * @method getMaxLength
   */
  getTools(id: string) {
    const obj: ObjType = {
      1: {
        maxLength: 70,
        text: '会议简介请输入10-70字'
      },
      2: {
        maxLength: 500,
        text: '字数超过500限制!'
      }
    };
    if (obj[id]) return obj[id];
    return {
      maxLength: 3500,
      text: '字数超过3500限制!'
    };
  }

  mounted() {
    (this.$refs.editInput as any).scrollTop = 0;
  }

  /** app回退
   * @method goBack
   */
  goBack() {
    this.$router.go(-1);
    return false;
  }

  /** 监听输入
   * @method handleInput
   * @param e
   */
  handleInput(e: any) {
    this.content = e.innerHTML;
    this.contentText = e.innerText;
  }

  /** 完成按钮
   * @method handleComplete
   */
  handleComplete() {
    if (!this.btnStatus) return;
    console.log(this.contentText.length);
    if (
      this.contentText.length > this.maxLength
    ) {
      this.$xxhToast(this.getTools(this.$route.params.flag).text);
      return;
    }
    if (!this.$route.params.flag && !/DOCTYPE/i.test(this.content)) {
      this.content = `<!DOCTYPE html>
        <html lang="en">
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Document</title>
          <style>
            * {
              padding: 0;
              margin: 0;
            }
          </style>
        </head>
        <body>
          <div style='font-size: 17px;color: #7f7f7f;'>${this.content}</div>
        </body>
        </html>`;
    }
    const contentData = {
      contentHtml: this.content,
      contentText: this.contentText
    };
    if (this.$route.params.flag) {
      this.$bus.$emit('setDraft', contentData);
    } else {
      this.$bus.$emit('setDraftCont', contentData);
    }
    this.$router.go(-1);
  }

  /**
   * 监听头部完成按钮
   */
  get btnStatus() {
    if (this.contentText) return this.contentText !== this.tempContentText;
    return !!this.contentText;
  }

  /**
   * 监听头部完成按钮状态
   */
  @Watch('btnStatus')
  statusChange(val: boolean) {
    console.log(val);
    if (val) {
      this.color = '#ffffff';
      this.bgColor = '#2CC07C';
    } else {
      this.color = '#B2B2B2';
      this.bgColor = '#F2F2F2';
    }
    jsCallAppParam(100, {
      title: '设置文稿',
      btnText: '完成',
      backText: '取消',
      color: this.color,
      bgColor: this.bgColor,
      callBack: 'handleComplete2'
    });
  }
}
</script>
<style lang="scss" scoped>
.edit-draft {
  width: 100%;
  background-color: #f7f7f7;
  padding-top: 0.16rem;
}
</style>
