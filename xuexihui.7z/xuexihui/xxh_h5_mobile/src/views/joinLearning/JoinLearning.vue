<template>
  <div class="join-bg">
    <div class="header">
      <img :src="`${imgDomain}/xxh/user/avatar/img/${userId}.jpg`"
           alt="" :onerror="defaultAvatar">
      {{detail.createdName}}
      <span v-if="false"> · 四合院志愿者</span>
      <span v-if="false" class="tag">系统</span>
    </div>
    <div class="content-box">
      <p class="tit">欢迎进入会场，本期会议主题</p>
      <p class="content">{{detail.themeName}}</p>
      <p class="tit">距离开始还剩</p>
      <p class="content">{{countdownString}}</p>
      <p class="tit" v-if="teacher.length > 0">主讲人</p>
      <p class="content" v-for="item in teacher" :key="item">{{item}}</p>
      <!--<p class="tit">会议嘉宾</p>-->
      <!--<p class="content">徐少春·金蝶集团董事长</p>-->
      <p class="tit">会议安排</p>
      <p class="content" v-for="(item, index) in agendaInfos" :key="index">
        {{index + 1}}.{{item.name}}
        <span v-if="item.extObj.timeUse">(</span>{{item.extObj.timeUse}}<span v-if="item.extObj.timeUse">)</span>
      </p>
    </div>
    <!--<div style="height: 0.94rem;"></div>-->
    <div class="btn1 add" @click="join">加入学习会</div>
  </div>
</template>

<script lang="ts">
import {
  Component,
  Vue
} from 'vue-property-decorator';
import { jsCallAppParam, countdown, imgDomain } from '../../assets/js/common';

@Component
export default class Confirm extends Vue {
  themeId: string | (string | null)[];

  agendaInfos: {ext: ''}[] = [];

  detail = {
    missionId: null
  };

  teacher: any[] = [];

  defaultAvatar = `this.src="${require('../../assets/img/default-avatar.jpg')}"`;

  countdownString = '00:00:00';

  timer: any;

  imgDomain = imgDomain;

  userId: string | (string | null)[];

  created() {
    this.themeId = this.$route.query.themeId;
    this.userId = this.$route.query.userId;
    this.init();
    window.appGoBack = () => {
      this.$router.go(-1);
      return true;
    };
  }

  init() {
    this.$http.get(`/mission/app/mission/queryThemeInfo/${this.themeId}`).then((res: any) => {
      this.detail = res;
      this.agendaInfos = res.agendaInfos || [];
      this.agendaInfos = this.agendaInfos.sort(this.compare('seq')); // 按照seq排序
      this.agendaInfos.forEach((item, index: number) => {
        if (item.ext) {
          const ext = JSON.parse(item.ext);
          this.$set(this.agendaInfos[index], 'extObj', ext);
          if (ext.speaker) { // 取出主讲人
            const str = ext.speaker.split(' ');
            this.teacher.push(str[1]);
          }
        }
      });
      jsCallAppParam(100, {
        title: res.themeName,
        title2: res.missionName
      });
      if (new Date().getTime() < new Date(res.startTime).getTime()) {
        let count = countdown(res.startTime);
        this.timer = setInterval(() => {
          if (count > 3600) {
            const hour = Math.floor(count / 3600);
            const min = Math.floor((count % 3600) / 60);
            const scend = Math.floor(count % 3600 % 60);
            this.countdownString = `${hour < 10 ? `0${hour}` : hour}:${min < 10 ? `0${min}` : min}:${scend < 10 ? `0${scend}` : scend}`;
          }
          count -= 1;
          if (count <= 0) {
            clearInterval(this.timer);
          }
        }, 1000);
      }
    });
  }

  compare(property: string) {
    return (a: any, b: any) => {
      const value1 = a[property];
      const value2 = b[property];
      return value2 - value1;
    };
  }

  join() {
    this.$http.post('/mission/app/mission/userAddMission', { missionId: this.detail.missionId }).then(() => {
      this.$xxhToast('加入成功,正在参与互动式学习');
      setTimeout(() => {
        jsCallAppParam(403, {
          data: JSON.stringify(this.detail)
        });
      }, 1500);
    });
  }

  destroy() {
    clearInterval(this.timer);
  }
}
</script>

<style scoped lang="scss">
.join-bg{
  background: $bg;
  height: 100%;
  overflow: auto;
}
.header{
  padding: 0.3rem 0.3rem 0.08rem;
  line-height: 0.6rem;
  text-align: left;
  font-size: 0.28rem;
  color: $text1;
  span{
    color: $text2;
    &.tag{
      display: inline-block;
      width: 0.76rem;
      height: 0.34rem;
      line-height: 0.38rem;
      margin-left: 0.1rem;
      background:rgba(44, 192, 124, 0.2);
      color: $first;
      text-align: center;
      border-radius: 0.17rem;
      font-size: 0.22rem;
     }
  }
  img{
    width: 0.6rem;
    height: 0.6rem;
    border-radius: 50%;
    float: left;
    margin-right: 0.14rem;
  }
}
.content-box{
  text-align: left;
  background: #fff;
  border-radius: 0.1rem;
  padding: 0.2rem;
  margin: 0 0.3rem 1.04rem 1.1rem;
  .tit{
    line-height: 0.42rem;
    color: $text2;
    font-size: 0.3rem;
    margin-top: 0.4rem;
    margin-bottom: 0.1rem;
    font-weight: 400;
    &:first-child{
       margin-top: 0;
     }
  }
  .content{
    font-size: 0.34rem;
    color: $text1;
    line-height: 0.48rem;
    font-weight: 500;
  }
}
.btn1.add{
  border-radius: 0;
  margin: 0;
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
}
</style>
