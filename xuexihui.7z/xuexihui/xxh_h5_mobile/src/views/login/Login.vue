<template>
  <div class="login">
    <h1>This is an login page</h1>
  </div>
</template>
<script lang="ts">
import { Vue } from 'vue-property-decorator';

export default class Login extends Vue {

}
</script>
