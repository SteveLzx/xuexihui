<template>
  <div class="setting-speaker">
    <div class="setting-speaker-box">
      <!-- type为 number 时 maxlength 失效 -->
      <input
        type="number"
        pattern="\d*"
        placeholder="输入主讲人手机号"
        v-model="mobile"
        @input="handleInput"
      />
      <div class="right">
        <transition name="fade">
          <i class="iconfont" @click="clearPhone" v-if="mobile.length">&#xe61a;</i>
        </transition>
        <span class="search" @click="handleSearch" :class="mobile.length ? 'active' : ''">搜索</span>
      </div>
    </div>
    <div class="result" v-if="dataReady">
      <div class="no-user" v-if="!userInfo">该手机号码未在本APP注册</div>
      <div class="has-user" v-else @click="handleChooseSpeaker">
        <img :src="userInfo.avatar" alt="" :onerror="defaultImg" />
        <div class="right">
          <p>{{userInfo.name}}</p>
          <p>{{userInfo.mobile}}</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Watch } from 'vue-property-decorator';
import OptionList from '@/components/page/OptionList.vue';
import { jsCallAppParam } from '@/assets/js/common';

@Component({
  components: { OptionList }
})
export default class SettingSpeaker extends Vue {
  // 手机号
  mobile = '';

  // 默认头像
  defaultImg = `this.src="${require('../../assets/img/default-avatar.jpg')}"`;

  // 数据加载完毕
  dataReady = false;

  // 用户信息
  userInfo = {};

  created() {
    jsCallAppParam(100, {
      title: '设置演讲人'
    });
    window.appGoBack = () => {
      this.$router.go(-1);
      return false;
    };
  }

  /** 搜索
   * @method handleSearch
   */
  handleSearch() {
    const params = {
      mobile: this.mobile
    };
    this.$http.post('/user/app/getUserInfoByMobile?mobile=', params)
      .then((res: object) => {
        this.dataReady = true;
        this.userInfo = res;
        if (res) {
          (this.userInfo as any).avatar = `${(res as any).avatar}?t=${new Date().getTime()}`;
        }
      });
  }

  /** 选择演讲人
   * @method handleChooseSpeaker
   */
  handleChooseSpeaker() {
    this.$bus.$emit('setSpeaker', this.userInfo);
    this.$router.go(-1);
  }

  /** 限制手机号11位输入长度
   * @method handleInput
   */
  handleInput(e: InputEvent) {
    if (e.target && (e.target as HTMLInputElement).value.length > 11) {
      this.mobile = (e.target as HTMLInputElement).value.slice(0, 11);
    }
  }

  /** 清空手机号
   * @method clearPhone
   */
  clearPhone() {
    this.mobile = '';
    this.dataReady = false;
  }

  /**
   * 监听手机号输入
   */
  // @Watch('mobile')
  // mobileChange(val: string) {
  //   if (!val.length) {
  //     this.clearPhone();
  //   }
  // }
}
</script>
<style lang="scss" scoped>
.setting-speaker {
  width: 100%;
  height: 100%;
  background-color: #f7f7f7;
  padding-top: 0.16rem;
  .setting-speaker-box {
    display: flex;
    justify-content: space-between;
    align-items: center;
    width: 100%;
    height: 1.12rem;
    background-color: #fff;
    margin-bottom: 0.16rem;
    input {
      flex: 1;
      border: 0;
      outline: 0;
      width: 100%;
      height: 100%;
      padding-left: 0.3rem;
      color: #000000;
      font-size: 0.34rem;
    }
    .right {
      height: 100%;
      display: flex;
      justify-content: center;
      align-items: center;
      i {
        font-size: 0.4rem;
        margin-right: 0.44rem;
        color: #b2b2b2;
      }
      span {
        padding: 0.15rem 0.26rem;
        color: #b2b2b2;
        background-color: #f2f2f2;
        border-radius: 0.32rem;
        font-size: 0.34rem;
        line-height: 0.34rem;
        margin-right: 0.3rem;
      }
      .active {
        color: #fff;
        background-color: #2cc07c;
      }
    }
  }
  .result {
    .no-user {
      background-color: #fff;
      width: 100%;
      height: 1.72rem;
      text-align: center;
      line-height: 1.72rem;
      color: #b2b2b2;
      font-size: 0.3rem;
      font-weight: 500;
    }
    .has-user {
      width: 100%;
      height: 1.44rem;
      background-color: #fff;
      display: flex;
      align-items: center;
      padding-left: 0.3rem;
      box-sizing: border-box;
      img {
        width: 0.96rem;
        height: 0.96rem;
        border-radius: 50%;
        margin-right: 0.24rem;
      }
      .right {
        p {
          text-align: left;
          font-family: PingFangSC-Regular;
          &:first-child {
            color: #000;
            font-size: 0.34rem;
            font-weight: 600;
            line-height: 0.48rem;
          }
          &:last-child {
            color: #2cc07c;
            font-size: 0.28rem;
            line-height: 0.4rem;
          }
        }
      }
    }
  }
}
.fade-enter-active, .fade-leave-active {
  transition: opacity .1s;
}
.fade-enter, .fade-leave-to /* .fade-leave-active below version 2.1.8 */ {
  opacity: 0;
}
</style>
