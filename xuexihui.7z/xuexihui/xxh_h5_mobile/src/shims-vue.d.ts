import Vue from 'vue';

declare module 'vue/types/vue' {
  interface Vue {
    $http: any;
    $loading: any;
    $xxhToast: any;
    versions: any;
    $bus: any;
  }
}
