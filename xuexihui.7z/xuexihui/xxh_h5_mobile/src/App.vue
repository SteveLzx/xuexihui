<template>
  <div id="app">
    <keep-alive>
      <router-view v-if="$route.meta.keepAlive" id="router"/>
    </keep-alive>
      <router-view v-if="!$route.meta.keepAlive" id="router"/>
  </div>
</template>
<script lang="ts">
import {
  Component,
  Vue
} from 'vue-property-decorator';
import { getQueryString } from './assets/js/common';

@Component
export default class APP extends Vue {
  showPage = false;

  beforeCreate() {
    const token = getQueryString('token') || localStorage.getItem('token_app') || '';
    localStorage.setItem('token_app', token);
    console.log(token);
  }

  created(): void {
    setTimeout(() => {
      this.showPage = true;
    }, 1000);

    window.appGoBack = () => {
      this.$router.go(-1);
      return false;
    };
  }

  showIt(val: string) {
    window.console.log(val);
  }
}
</script>
<style lang="scss">
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  background: #fff;
  height: 100%;
  &.skeleton{
    /*background: url('./gujia.png') no-repeat;*/
    /*background-size: 100% auto;*/
  }
}
#router{
  transition: 1s;
  opacity: 1;
  &.show-opacity{
    opacity: 1;
  }
}
</style>
