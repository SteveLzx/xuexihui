<!--
属性：
1.左侧标题直接传 title="我是标题"
2.需要border的直接加上border属性,无需传值 border
3.占位内容placeholder
4.标题置灰gray
类型
1.选择类型，直接添加点击事件@click
2.switch切换类型
  2.1 不允许切换的直接添加isDisabled属性，无需传值 isDisabled
  2.2 有默认值的直接传value="false" || value="true" 默认false
  2.3 务必在父组件写switchChange方法，接收一个参数为点击改变后的状态 true/false
3.输入类型
  3.1 需要右箭头 增加属性input-icon
  3.2 v-model获取值
4.上传文件
  4.1 file="video" 指定上传文件类型，暂时支持video和audio
  4.2 v-model="video" {result: '',name: ''} 这样的一个对象
  4.3 上传成功回调 uploadComplete 返回 {result: '',name: ''}
  4.4 删除回调 fileDelete

-->
<template>
  <div v-if="!$attrs.hasOwnProperty('input')">
    <div class="list-box" v-on="$listeners">
      <div
        class="border-box"
        :class="{
          'has-border': $attrs.hasOwnProperty('border') && $attrs.border.toString() !== 'false'
        }"
      >
        <!--标题-->
        <span :class="$attrs.hasOwnProperty('gray') && $attrs.gray.toString() !== 'false' ? 'gray' : ''">{{ $attrs.title }}</span>
        <!--选择类型-->
        <div class="model1" v-if="$attrs.hasOwnProperty('choose')">
          <span
            class="des"
            :class="
              $attrs.hasOwnProperty('disabled') && $attrs.disabled.toString() !== 'false'
                ? 'disabled'
                : ''
            "
            v-bind="$attrs"
            >{{ chooseValue }}</span
          >
          <i
            class="iconfont right"
            v-if="iconValue"
            :class="
              $attrs.hasOwnProperty('disabled') && $attrs.disabled.toString() !== 'false'
                ? 'disabled'
                : ''
            "
          >
            &#xe61f;
          </i>
        </div>
        <!--按钮类型-->
        <input
          v-if="$attrs.hasOwnProperty('switch')"
          class="model2"
          type="checkbox"
          :disabled="$attrs.hasOwnProperty('disabled') && $attrs.disabled.toString() !== 'false'"
          :checked="$attrs.value"
          @click="switchClick($event)"
        />
        <!--单选类型-->
        <i class="iconfont model4" v-if="$attrs.hasOwnProperty('select') && selectValue">
          &#xe61c;
        </i>
        <!-- 上传 .mp4 .mp3-->
        <div class="model5" v-if="$attrs.hasOwnProperty('file')">
          <label class="des"
            :placeholder="$attrs.placeholder"
            :for="$attrs.file"
            :class="
              $attrs.hasOwnProperty('disabled') && $attrs.disabled.toString() !== 'false'
                ? 'disabled'
                : ''
            "
          >{{ uploadContent }}</label>
          <input
            type="file"
            :accept="$attrs.file === 'video' ? 'video/*' : $attrs.file === 'audio' ? 'audio/*' : ''"
            :id="$attrs.file"
            @change="handleChange"
            :disabled="$attrs.hasOwnProperty('disabled') && $attrs.disabled.toString() !== 'false'"
            ref="file"
          />
          <i
            class="iconfont right"
            v-if="!uploadStatus"
            :class="
              $attrs.hasOwnProperty('disabled') && $attrs.disabled.toString() !== 'false'
                ? 'disabled'
                : ''
            "
          >&#xe61f;</i>
          <i
            class="iconfont delete"
            @click="handleDelete"
            :class="
              $attrs.hasOwnProperty('disabled') && $attrs.disabled.toString() !== 'false'
                ? 'disabled'
                : ''
            "
          v-else>&#xe61d;</i>
        </div>
      </div>
    </div>
  </div>
  <div v-else>
    <!--输入类型-->
    <div class="list-box">
      <div
        class="border-box"
        :class="{
          'has-border': $attrs.hasOwnProperty('border') && $attrs.border.toString() !== 'false'
        }"
      >
        <!--标题-->
        <span>{{ $attrs.title }}</span>
        <div class="model3">
          <i class="iconfont right" v-if="$attrs.hasOwnProperty('input-icon')">&#xe61f;</i>
          <input
            type="text"
            @input="$emit('input', $event.target.value)"
            v-bind="$attrs"
            v-filter-emoji
          />
        </div>
      </div>
    </div>
  </div>
</template>
<script lang="ts">
import {
  Component, Vue, Prop, Emit, Watch
} from 'vue-property-decorator';


@Component
export default class OptionList extends Vue {
  @Prop({
    type: String
  })
  chooseValue: string;

  @Prop({
    type: Boolean || String
  })
  selectValue: boolean | string;

  @Prop({
    type: Boolean,
    default: true
  })
  iconValue: boolean;

  currentValue = this.$attrs.switch === '' && this.$attrs.value.toString() === 'true';

  uploadStatus = this.$attrs.value && (this.$attrs.value as any).result;

  uploadContent = this.$attrs.value && (this.$attrs.value as any).name;

  handleChange(e: Event) {
    const { files }: any = e.target;
    let file: File;
    let usageScenarios = '';
    if (files.length) {
      [file] = Array.from(files);
      console.log(file);
      console.log(file.name, file.type);
      if (
        this.$attrs.file === 'video'
        && !/\.(mp4|mov|quicktime)$/i.test(file.name.toLowerCase())
      ) {
        this.$xxhToast('不支持该类格式文件');
        // 清空上传的本地资源
        (this.$refs.file as any).value = null;
        return;
      }
      if (this.$attrs.file === 'audio' && !/\.(mp3|mpeg)$/i.test(file.name.toLowerCase())) {
        this.$xxhToast('不支持该类格式文件');
        // 清空上传的本地资源
        (this.$refs.file as any).value = null;
        return;
      }
      // 文件大小处理
      const size = `${(file.size / 1024 / 1024).toFixed(2)}M`;
      const formData: FormData = new FormData();
      formData.append('file', file);
      if (this.$attrs.file === 'video') {
        usageScenarios = '3';
      } else if (this.$attrs.file === 'audio') {
        usageScenarios = '4';
      }
      formData.append('usageScenarios', usageScenarios);
      const self = this;
      // 文件名字做处理
      const nameStr = file.name.substring(0, file.name.lastIndexOf('.'));
      const nameStr1 = file.name.substring(file.name.lastIndexOf('.'), file.name.length);
      let name = '';
      if (nameStr.length > 6) {
        name = `${nameStr.substring(0, 6)}... ${nameStr1} ${size}`;
      } else {
        name = `${file.name} ${size}`;
      }
      this.$http({
        method: 'post',
        url: '/base/mng/upload/audioOrVideo',
        data: formData,
        onUploadProgress: (evt: any) => {
          // 此处不乘以100，是因为，在实际上传过程中，loaded比较早的就100%了，但实际接口尚未成功返回；所以接口没回来之前，不超过99%
          if (evt) {
            self.uploadContent = `${name.split(' ')[0]} ${name.split(' ')[1]} ${Math.round(
              (evt.loaded / evt.total) * 99
            )}%`;
            if (evt.loaded < evt.total) {
              self.uploadStatus = false;
            } else {
              self.uploadContent = name;
              self.uploadStatus = true;
            }
          }
        }
      })
        .then((res: any) => {
          console.log(res);
          this.$emit('uploadComplete', {
            result: res.conversionUrl,
            name: `${file.name} ${size}`
          });
        })
        .catch((err: any) => {
          this.uploadContent = '';
          this.uploadStatus = false;
          // 清空上传的本地资源
          (this.$refs.file as any).value = null;
        });
    }
  }

  handleDelete() {
    if (this.$attrs.disabled) return;
    this.$emit('fileDelete');
    this.uploadContent = '';
    this.uploadStatus = false;
    // 清空上传的本地资源
    (this.$refs.file as any).value = null;
    this.$xxhToast('已删除');
  }

  switchClick() {
    if (this.$parent && (this.$parent as any).switchChange) {
      this.currentValue = !this.currentValue;
      (this.$parent as any).switchChange(this.currentValue);
    } else {
      console.error('哥们，父组件写个switchChange方法');
    }
  }
}
</script>
<style lang="scss" scoped>
.list-box {
  padding-left: 0.3rem;
  background-color: #fff;
}
.border-box {
  padding-right: 0.3rem;
  text-align: left;
  color: #000;
  font-size: 0.34rem;
  line-height: 1.12rem;
  position: relative;
  display: flex;
  overflow: hidden;
  height: 1.12rem;
  justify-content: space-between;
  &.has-border {
    border-bottom: $line solid 0.01rem;
  }
  .model1 {
    color: $text2;
    font-size: 0.34rem;
    width: 60%;
    height: 1.12rem;
    display: flex;
    >span {
      flex: 1;
      text-align: right;
    }
  }
  .iconfont.right {
    color: $text3;
    margin-left: 0.1rem;
    font-size: .24rem;
  }
}
.model2 {
  position: absolute;
  top: 50%;
  right: 0.3rem;
  transform: translateY(-50%);
  width: 1rem;
  height: 0.6rem;
  border: 1px solid $line;
  outline: 0;
  border-radius: 0.3rem;
  box-sizing: border-box;
  background-color: $line;
  transition: background-color 0.1s, border 0.1s;
  appearance: none;
  &:disabled {
    opacity: 0.6;
  }
  &::before {
    content: " ";
    position: absolute;
    top: 0;
    left: 0;
    width: 0.96rem;
    height: 0.56rem;
    border-radius: 0.28rem;
    background-color: #fdfdfd;
    transition: transform 0.35s cubic-bezier(0.45, 1, 0.4, 1),
      -webkit-transform 0.35s cubic-bezier(0.45, 1, 0.4, 1);
  }
  &::after {
    content: " ";
    position: absolute;
    top: 0;
    left: 0;
    width: 0.56rem;
    height: 0.56rem;
    border-radius: 0.28rem;
    background-color: #ffffff;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.4);
    transition: transform 0.35s cubic-bezier(0.4, 0.4, 0.25, 1.35),
      -webkit-transform 0.35s cubic-bezier(0.4, 0.4, 0.25, 1.35);
  }
  &:checked {
    background-color: #09bb07;
  }
  &:checked::before {
    transform: scale(0);
  }
  &:checked::after {
    transform: translateX(22px);
  }
}
.model3 {
  width: 60%;
  height: 1.12rem;
  float: right;
  input {
    width: 100%;
    background: transparent;
    border: 0;
    font-size: 0.34rem;
    line-height: 0.4rem;
    text-align: right;
    color: $text2;
  }
}
.model4 {
  float: right;
  font-size: 0.28rem;
  color: $first;
}
.model5 {
  display: flex;
  color: $text2;
  font-size: 0.34rem;
  > input {
    display: none;
  }
  .delete {
    font-size: 0.34rem;
    color: $text3;
    margin-left: 0.3rem;
  }
}
.des:empty:before {
  content: attr(placeholder) !important;
  color: $text3 !important;
}
input:disabled {
  opacity: 0.4;
}
.disabled {
  opacity: 0.4;
}
.gray {
  color: $text3;
}
</style>
