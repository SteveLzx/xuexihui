<template>
  <div class='edit-input'>
    <div
      class='edit-input-box'
      ref='editDraftBox'
    >
      <div
        class='edit'
        ref='editDraft'
        @input="handleInput"
        @blur="handleBlur"
        @compositionend='compositionend'
        @compositionstart='compositionstart'
        v-html='currentContent'
        :class="
          $attrs.hasOwnProperty('disabled') && $attrs.disabled.toString() !== 'false'
            ? 'disabled'
            : ''
        "
        :contenteditable="!$attrs.hasOwnProperty('disabled') || ($attrs.hasOwnProperty('disabled') && $attrs.disabled.toString() !== 'true')"
        :placeholder='placeholder'
        :style="{'min-height': minHeight}"
      ></div>
      <div class='upload' v-if='isOpenUploadImg'>
        <div class='upload-btn' @click='handleChoose'></div>
      </div>
      <div class='placeholder' v-if="space == 'true'"></div>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Prop } from 'vue-property-decorator';
import { jsCallAppParam } from '@/assets/js/common';

@Component
export default class EditDraft extends Vue {
  @Prop({ // 最大字数限制
    type: Number
  })
  maxLength: number;

  @Prop({ // 最小字数字数限制
    type: Number
  })
  minLength: number;

  @Prop({ // 是否开启上传图片入口
    type: Boolean,
    default: false
  })
  isOpenUploadImg: boolean;

  @Prop({ // 是否开启上传图片入口
    type: String,
    default: '点击输入内容'
  })
  placeholder: string;

  @Prop({ // 是否需要底部空格
    type: String,
    default: 'false'
  })
  space: string

  @Prop({
    type: String,
    default: '2.7rem'
  })
  minHeight: string;

  @Prop({
    type: String,
    default: 'false'
  })
  isRichText: boolean

  // 文稿内容，用于传递
  content = this.$attrs.value || '';

  // 当前显示文稿
  currentContent = this.$attrs.value || '';

  // 输入状态
  lock = true;

  created() {
    window.getImage = this.getImage;
  }

  /** 文稿输入
   * @method handleInput
   * @param {Event} e
   */
  handleInput(e: Event) {
    if (this.isRichText) {
      this.addInput(e);
    }
    this.content = (e.target as any).innerHTML;
    if ((e.target as any).innerHTML === '<br>') {
      (e.target as any).innerHTML = '';
    }
    this.$emit('input', e.target);
  }

  /** 失去焦点事件
   * @method hanldeBlur
   */
  handleBlur() {
    this.$emit('blur');
  }

  /** 中文输入开始
   * @method compositionstart
   */
  compositionstart() {
    this.lock = false;
  }

  /** 中文输入结束
   * @method compositionend
   * @param {Event} e
   */
  compositionend(e: Event) {
    this.lock = true;
    if (this.isRichText) {
      this.addInput(e);
    }
  }

  /** 编辑器输入
   * @method addInput
   * @param {Event} e
   */
  addInput(e: Event) {
    const _words = (e.target as any).innerText;
    if (this.lock) {
      const num = _words.length;
      if (num >= this.maxLength) {
        (e.target as any).innerText = _words
          .trim()
          .substring(0, this.maxLength);
      }
      this.$emit('input', e.target);
      this.keepLastIndex(e.target);
    }
  }

  /** 编辑器光标错位纠正
   * @method keepLastIndex
   * @param {any} obj
   */
  keepLastIndex(obj: any) {
    if (window.getSelection) {
      // ie11 10 9 ff safari
      obj.focus(); // 解决ff不获取焦点无法定位问题
      const range = window.getSelection(); // 创建range
      if (range) {
        range.selectAllChildren(obj); // range 选择obj下所有子内容
        range.collapseToEnd(); // 光标移至最后
      }
    } else if ((document as any).selection) {
      // ie10 9 8 7 6 5
      const range = (document as any).selection.createRange(); // 创建选择对象
      // var range = document.body.createTextRange();
      range.moveToElementText(obj); // range定位到obj
      range.collapse(false); // 光标移至最后
      range.select();
    }
  }

  /** 上传图片
   * @method handleChoose
   */
  handleChoose() {
    jsCallAppParam(406, {});
  }

  /** 上传图片app回调
   * @method getImage
   * @param {Array<string>} data
   */
  getImage(data: Array<string>) {
    console.log(data);
    let str = '';
    data.forEach((item: string) => {
      str += ` <img src="${item}" style="width: 100%;margin-bottom: 4px;" alt=""> `;
    });
    this.content += str;
    this.currentContent = this.content;
    this.$emit('input', {
      innerHTML: this.content,
      innerText: this.content
    });
  }
}
</script>
<style lang="scss" scoped>
.edit-input {
  width: 100%;
  height: 100%;
  background-color: #f7f7f7;
  .edit-input-box {
    width: 100%;
    min-height: 100%;
    background-color: #fff;
    box-sizing: border-box;
    .edit {
      padding: 0.3rem 0.3rem;
      width: 100%;
      text-align: left;
      outline: 0;
      border: 1px solid transparent;
      font-size: 0.34rem;
      color: #7f7f7f;
      word-break: break-all;
      box-sizing: border-box;
      &:empty::after {
        content: attr(placeholder);
        color: #333;
        font-size: 0.34rem;
        line-height: 0.34rem;
        opacity: 0.5;
      }
      img {
        width: 100%;
      }
    }
    .upload {
      margin: .5rem 0 2rem 0;
      padding-left: .3rem;
      box-sizing: border-box;
      .upload-btn {
        width: 1.2rem;
        height: 1.2rem;
        border: 0.02rem solid #e5e5e5;
        border-radius: 0.1rem;
        position: relative;
        &::before {
          content: '';
          position: absolute;
          width: 0.6rem;
          height: 0.02rem;
          background-color: #e5e5e5;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
        }
        &::after {
          content: '';
          position: absolute;
          height: 0.6rem;
          width: 0.02rem;
          background-color: #e5e5e5;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
        }
      }
    }
    .placeholder {
      width: 100%;
      height: 1rem;
      background-color: #fff;
      box-sizing: border-box;
    }
    .disabled {
      opacity: 0.4;
    }
  }
}
</style>
