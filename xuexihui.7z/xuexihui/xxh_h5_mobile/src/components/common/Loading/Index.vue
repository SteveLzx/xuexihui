/*
//显示loading
this.$loading.show();

//显示带字符串loading
this.$loading.show({text:"加载中"});
//可以直接传字符串
this.$loading.show("加载中...");

//loading延时关闭, 默认30秒
this.$loading.show({timeout: 30});

//隐藏loading
this.$loading.hide();
*/
<template>
  <div class="full-screen-bg2">
    <div class="loading-box" :class="{'active': !text}">
      <i class="xxh-loading"></i>
      <p class="text" v-if="text">{{text}}</p>
    </div>
  </div>
</template>
<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';

@Component
export default class Loading extends Vue {
  public text = '';
}
</script>
<style lang="scss" scoped>
.loading-box{
  text-align: center;
  position: absolute;
  left: 50%;
  top: 5rem;
  transform: translateX(-50%);
  width: 2.4rem;
  height: 2.4rem;
  background-color: rgba(0, 0, 0, 0.7);
  border-radius: 0.1rem;
  .text{
    line-height: 0.3rem;
    color: #fff;
    font-size: 0.3rem;
  }
  &.active{
    line-height: 2.4rem;
    .xxh-loading{
      margin: 0;
    }
  }
}
.xxh-loading{
  width: 0.52rem;
  height: 0.52rem;
  margin: 0.6rem 0 0.38rem;
  display: inline-block;
  vertical-align: middle;
  animation: shyLoading .8s steps(12, end) infinite;
  background: url('../../../assets/img/loading-1.png') no-repeat center center;
  background-size: 100% 100%;
}
@-webkit-keyframes shyLoading {
  0% {
    transform: rotate3d(0, 0, 1, 0deg);
  }

  100% {
    transform: rotate3d(0, 0, 1, 360deg);
  }
}
@keyframes shyLoading {
  0% {
    transform: rotate3d(0, 0, 1, 0deg);
  }

  100% {
    transform: rotate3d(0, 0, 1, 360deg);
  }
}
</style>
