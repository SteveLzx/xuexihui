import Vue from 'vue';
import Loading from './Index.vue';

type LoadingOption = {
    text?: string;
    timeout?: number;
}
const LoadingBox = Vue.extend(Loading);
const instance = new LoadingBox().$mount();
let timer: any = null;
const loading = {
  show: (options: LoadingOption | string) => {
    let text = '数据加载中';
    let timeout = 30;
    if (options && typeof options === 'object') {
      text = options.text || '数据加载中';
      timeout = options.timeout || 30;
    }
    if (options && typeof options === 'string') text = options;
    instance.$data.text = text;
    document.body.appendChild(instance.$el);
    timer = setTimeout(() => {
      clearTimeout(timer);
      if (instance && instance.$el) {
        document.body.removeChild(instance.$el);
      }
    }, timeout * 1000);
  },
  hide: () => {
    clearTimeout(timer);
    if (instance && instance.$el) {
      setTimeout(() => {
        document.body.removeChild(instance.$el);
      }, 10);
    }
  }
};

export default loading;
