<!--
<DateTimePicker :showPicker="showPicker3" @cancel="showPicker3 = false"
                    :minDate="minDate"
                    type="dateTime"
                    :maxDate="maxDate" default="2020-02-21 20:20"
                    @confirm="onConfirm3"/>
showPicker: 控制显示隐藏
@confirm：确认按钮的回调
:minDate: 最小日期，格式 2020-02-02
:maxDate: 最大日期，格式 2020-02-02
type: 日期+时间(dateTime) || 日期(date) || 时间(time)
default: 默认值 dateTime: 2020-02-02 12:20 || date: 2020-02-02 || time: 12:20
@cancel：必写，关闭后才能再次打开
-->
<template>
  <div id='dateTime' :class="{'active': type === 'dateTime'}">
    <van-popup v-model='isShow' position='bottom' @closed='onCancel'>
      <van-picker
        show-toolbar
        :columns='dateTimeList'
        @cancel='onCancel'
        @confirm='onConfirm'
        confirm-button-text='完成'
        item-height='56'
        :default-index='$attrs["default-index"] || 0'
      />
    </van-popup>
  </div>
</template>

<script lang='ts' scoped>
import {
  Component,
  Vue,
  Prop,
  Watch,
  Emit
} from 'vue-property-decorator';
import 'vant/lib/index.css';
import { Picker, Popup } from 'vant';
import { filterTimeToDate, getAllDate } from '../../assets/js/common';

Vue.use(Picker);
Vue.use(Popup);

@Component
export default class DateTimePicker extends Vue {
  @Prop({ // 控制显示隐藏
    type: Boolean,
    default: false
  })
  showPicker: boolean;

  @Prop({ // 最小时间，默认当天
    type: String,
    default: new Date().toLocaleDateString()
  })
  minDate: string;

  @Prop({ // 最大时间，默认当天的一个月后
    type: String,
    default: ''
  })
  maxDate: string;

  @Prop({ // 默认值，可为空，可传年月日，可传年月日时分
    type: String,
    default: filterTimeToDate().dateTime
  })
  default: string;

  @Prop({ // 选择格式 默认年月日 可选: 年月日时分(dateTime) || 年月日(date) || 时分(time)
    type: String,
    default: 'dateTime'
  })
  type: string;

  dateTimeList = [ // 列表
    {
      values: [],
      defaultIndex: 0
    },
    {
      values: ['00', '01', '02', '03', '04', '05', '06', '07', '08', '09', 10, 11, 12, 13,
        14, 15, 16, 17, 18, 19, 20, 21, 22, 23],
      defaultIndex: 0
    },
    {
      values: ['00', '01', '02', '03', '04', '05', '06', '07', '08', '09', 10, 11, 12, 13,
        14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26,
        27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39,
        40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52,
        53, 54, 55, 56, 57, 58, 59],
      defaultIndex: 0
    }
  ];

  isShow = false;

  created() {
    const { minDate, maxDate } = this.getDefaultDate();
    // 获取两个日期中间的日期给第一列赋值
    const diffDate = getAllDate(minDate, maxDate);
    // this.dateTimeList[0].values = diffDate;
    this.$set(this.dateTimeList[0], 'values', diffDate);
    this.filterDefaultIndex(diffDate); // 默认值筛选
    if (this.type === 'date') { // 只有date
      this.dateTimeList = [this.dateTimeList[0]];
    }
    if (this.type === 'time') { // 只有time
      this.dateTimeList = [this.dateTimeList[1], this.dateTimeList[2]];
    }
  }

  getDefaultDate() { // 获取默认时间
    let { minDate, maxDate } = this;
    if (!minDate) { // 默认从今天开始
      minDate = new Date().toLocaleDateString();
    }
    if (!maxDate) { // 默认当前时间加一个月
      const date = new Date();
      date.setMonth(date.getMonth() + 1);
      maxDate = date.toLocaleDateString();
    }
    // 转为/格式兼容
    minDate = minDate.includes('-') ? minDate.replace(/-/g, '/') : minDate;
    maxDate = maxDate.includes('-') ? maxDate.replace(/-/g, '/') : maxDate;

    return {
      minDate,
      maxDate
    };
  }

  filterDefaultIndex(diffDate: any[]) {
    if (!this.default) return;
    if (this.type === 'dateTime') { // 日期加时间类型
      const r = this.default.match(/^(\d{1,4})(-|\/)(\d{1,2})(-|\/)(\d{1,2})( )(\d{2})(:)(\d{2})$/);
      if (!r) {
        console.error('传的默认值格式不对,例如 2020-02-12 20:20');
        this.onCancel();
        return;
      }
      const dateTime = this.default.split(' ');
      this.typeDate(diffDate, dateTime[0]);
      this.typeTime(dateTime[1]);
    }
    if (this.type === 'date') { // 日期类型
      this.typeDate(diffDate, this.default);
    }
    if (this.type === 'time') { // 时间类型
      this.typeTime(this.default);
    }
  }

  typeDate(diffDate: any[], date: string) {
    const r = date.match(/^(\d{1,4})(-|\/)(\d{1,2})(-|\/)(\d{1,2})$/);
    if (!r) {
      console.error('传的默认值格式不对,例如 2020-02-12');
      this.onCancel();
      return;
    }
    this.filterDateIndex(diffDate, date);
  }

  typeTime(time: string) {
    const r = time.match(/^(\d{2})(:)(\d{2})$/);
    if (!r) {
      console.error('传的默认值时间格式不对,例如 12:20');
      this.onCancel();
      return;
    }
    const hourMin = time.split(':');
    if (Number(hourMin[0]) > 23 || Number(hourMin[0]) < 0 || Number(hourMin[1]) > 59 || Number(hourMin[1]) < 0) {
      console.error('传的默认值时间格式不对,例如 12:20');
      this.onCancel();
      return;
    }
    this.filterTimeIndex(this.dateTimeList[1].values, hourMin[0], 1);
    this.filterTimeIndex(this.dateTimeList[2].values, hourMin[1], 2);
  }

  filterDateIndex(diffDate: any[], date: string) {
    diffDate.forEach((item: any, index: number) => {
      if (item.value === date.replace(/\//g, '-')) {
        this.dateTimeList[0].defaultIndex = index;
      }
    });
    if (!this.dateTimeList[0].defaultIndex) {
      console.error('请确保传的默认值在当前时间范围内');
      this.onCancel();
    }
  }

  filterTimeIndex(timeArr: any[], value: string, listIndex: number) {
    timeArr.forEach((item, index) => {
      if (item.toString() === value) {
        this.dateTimeList[listIndex].defaultIndex = index;
      }
    });
  }

  @Emit('confirm') // 确认的回调
  onConfirm(value: [any, any, any], index: number) {
    console.log(value);
    this.isShow = false;
    if (this.type === 'time') return value.join(':');
    if (this.type === 'date') return value[0].value;
    if (this.type === 'dateTime') {
      const textArr = value[0].text.split(' ');
      const valueArr = value[0].value.split('-');
      return {
        dataTime: `${value[0].value} ${value[1]}:${value[2]}:00`,
        showTime: `${valueArr[1]}月${valueArr[2]}日 ${textArr[1]} ${value[1]}:${value[2]}`
      };
    }
    return {
      value,
      index
    };
  }

  @Emit('cancel') // 取消的回调
  onCancel() {
    this.isShow = false;
  }

  @Watch('showPicker') // 监听显示和隐藏
  change(val: boolean) {
    this.isShow = val;
  }
}
</script>

<style lang='scss'>
#dateTime{
  .van-picker{
    position: relative;
  }
  .van-picker__toolbar{
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    z-index: 10;
    height: 56px;
    line-height: 56px;
    border-top: 8px solid $line;
    border-bottom: none;
    display: flex;
    background: #fff;
  }
  .van-picker__cancel, .van-picker__confirm{
    font-size: 0.34rem;
    color: $text1;
    text-align: center;
    flex: 1;
  }
  .van-picker__confirm{
    color: $first;
  }
  .van-picker__cancel{
    border-right: solid 1px $line;
  }
  .van-hairline-unset--top-bottom.van-picker__frame{
    transform: translateY(0);
    top: 112px;
  }
  .van-picker__columns{
    padding-bottom:  64px;
  }
  .van-popup{
    border-top-left-radius: 10px;
    border-top-right-radius: 10px;
    overflow: hidden;
  }
  .van-picker__mask{
    background-size: 100% 148px!important;
    top: -30px;
  }
  &.active{
    .van-picker-column:first-child {
      flex: 2;
      min-width: 210px;
      .van-picker-column__wrapper {
        width: 210px;
      }
    }
  }
}
</style>
