<!--
<ActionSheet :show="showPicker2" @cancel="showPicker2 = false"
             :columns="columns"
             @confirm="onConfirm2"/>
:showPicker 控制显示隐藏
@cancel 必传，将控制显示隐藏的变量置为false
:columns 必传, 传字符串数组或者对象数组，对象数组需要以text为key装要显示的值,例:[{text: '选项', id: 1}]
@confirm 必传, 确认的回调
-->
<template>
  <div>
    <van-popup v-model="isShow" position="bottom" @closed="onCancel">
      <div class="sheet-box">
        <ul>
          <li class="option" v-for="(item, index) in columns"
              :key="index" @click="onConfirm(item, index)">
            {{typeof item === 'object' ? item.text : item}}
          </li>
        </ul>
        <div class="cancel" @click="isShow = false">
          取消
        </div>
      </div>
    </van-popup>
  </div>
</template>

<script lang="ts">
import {
  Component,
  Vue,
  Prop,
  Watch,
  Emit
} from 'vue-property-decorator';
import 'vant/lib/index.css';
import { Popup } from 'vant';

Vue.use(Popup);
@Component
export default class ActionSheet extends Vue {
  isShow = false;

  @Prop({
    type: Boolean
  }) showPicker: boolean;

  @Prop({
    type: Array
  })
  columns: any[];

  @Emit('cancel')
  onCancel() {
    console.log('关闭');
  }

  @Emit('confirm')
  onConfirm(item: any, index: number) {
    this.isShow = false;
    this.onCancel();
    return {
      value: item,
      index
    };
  }

  @Watch('showPicker')
  change(val: boolean) {
    if (!this.columns || this.columns.length === 0) {
      console.error('哥们,传columns啊');
      this.onCancel();
      return;
    }
    if (this.columns.length > 5) {
      console.error('哥们,超过5个选项用PopupPicker');
      this.onCancel();
      return;
    }
    this.isShow = val;
  }
}
</script>

<style scoped lang="scss">
.sheet-box{
  background: #fff;
  color: $text1;
  font-size: 0.34rem;
  .option{
    line-height: 1.12rem;
    border-bottom: solid 0.01rem $line;
  }
  .cancel{
    line-height: 1.12rem;
    text-align: center;
    border-top: solid 0.16rem $line;
  }
}
.van-popup{
  border-top-left-radius: 10px;
  border-top-right-radius: 10px;
  overflow: hidden;
}
</style>
