<!--
<PopupPicker :showPicker="selectValue" @onConfirm="onConfirm"
             :columns="columns" default-index="3"
              @cancel="showPicker = false"/>
showPicker: 控制显示隐藏
@confirm：确认按钮的回调
columns: 选项值，数组类型，若数组内是对象,要展示的值的key为text,如[{text: '选项'， id: 2}]
default-index: 默认选项
@cancel：必写，关闭后才能再次打开
-->
<template>
  <div id="pop">
     <van-popup v-model="isShow" position="bottom" @closed="onCancel">
        <van-picker
          show-toolbar
          :columns="columns"
          @cancel="onCancel"
          @confirm="onConfirm"
          confirm-button-text='完成'
          item-height="56"
          :default-index="$attrs['default-index'] || 0"
        />
     </van-popup>
  </div>
</template>

<script lang="ts" scoped>
import {
  Component,
  Vue,
  Prop,
  Watch,
  Emit
} from 'vue-property-decorator';
import 'vant/lib/index.css';
import { Picker, Popup } from 'vant';

Vue.use(Picker);
Vue.use(Popup);
@Component
export default class PopupPicker extends Vue {
    @Prop({
      type: Boolean,
      default: false
    })
    showPicker: boolean;

    @Prop({
      type: Array
    })
    columns: any[];

    isShow = false;

    @Emit('confirm')
    onConfirm(value: string, index: number) {
      this.isShow = false;
      return {
        value,
        index
      };
    }

    @Emit('cancel')
    onCancel() {
      this.isShow = false;
    }

    @Watch('showPicker')
    change(val: boolean) {
      if (!this.columns || this.columns.length === 0) {
        console.error('哥们,传columns啊');
        this.onCancel();
        return;
      }
      if (this.columns.length <= 5) {
        console.error('哥们,5个及以下的选项用ActionSheet');
        this.onCancel();
        return;
      }
      this.isShow = val;
    }
}
</script>

<style lang='scss'>
.van-picker{
  position: relative;
}
.van-picker__toolbar{
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  z-index: 10;
  height: 56px;
  line-height: 56px;
  border-top: 8px solid $line;
  border-bottom: none;
  display: flex;
  background: #fff;
}
.van-picker__cancel, .van-picker__confirm{
  font-size: 0.34rem;
  color: $text1;
  text-align: center;
  flex: 1;
}
.van-picker__confirm{
  color: $first;
}
.van-picker__cancel{
  border-right: solid 1px $line;
}
.van-hairline-unset--top-bottom.van-picker__frame{
  transform: translateY(0);
  top: 112px;
}
.van-picker__columns{
  padding-bottom:  64px;
}
.van-popup{
  border-top-left-radius: 10px;
  border-top-right-radius: 10px;
  overflow: hidden;
}
.van-picker__mask{
  background-size: 100% 148px!important;
  top: -30px;
}
</style>
