<template>
  <div>

  </div>
</template>

<script lang="ts">
import {
  Component,
  Vue,
  Prop
} from 'vue-property-decorator';

@Component
export default class Confirm extends Vue {

}
</script>

<style scoped>

</style>
