<template>
  <div class="upload-box">
    <label for="upImg">
      <slot></slot>
      <input type="file" accept="image/*" id="upImg" @change="chooseImg">
    </label>
  </div>
</template>

<script lang="ts">
import {
  Vue,
  Component,
  Emit
} from 'vue-property-decorator';

// 图片最大空间，单位kb (例：maxSize='1024' 最大为1024kb)
@Component
export default class UploadImg extends Vue {
  chooseImg(e: Event) {
    const { files } = e.target as HTMLInputElement;
    let file: File;
    if (files) {
      [file] = Array.from(files);
      if (!file) return;
      console.log(`原图---${(file.size / 1024).toFixed(2)}KB`);
      const maxSize = (this.$attrs && this.$attrs.maxSize) || 0;
      if ((file.size / 1024) > maxSize) {
        window.alert('图片太大了兄弟');
        return;
      }
      this.compressFile(file);
    }
  }

  /**
   * 压缩图片
   * @param file input获取到的文件
   */
  compressFile(file: File) {
    const fileObj = file;
    // 图片转换为base64
    const reader = new FileReader();
    reader.readAsDataURL(fileObj);
    reader.onload = (e: ProgressEvent) => {
      const image = new Image();
      image.src = (e.target as FileReader).result as string;
      // this.imgSrc = (e.target as FileReader).result as string;
      image.onload = () => {
        // canvas将图分辨率缩小
        this.drawImg(image, fileObj);
      };
    };
  }

  drawImg(image: HTMLImageElement, fileObj: File) { // canvas绘图
    const canvas = document.createElement('canvas');
    const context: CanvasRenderingContext2D | any = canvas.getContext('2d');
    const imageWidth = image.width;
    const imageHeight = image.height;
    canvas.width = imageWidth;
    canvas.height = imageHeight;
    context.drawImage(image, 0, 0, imageWidth, imageHeight);
    const data = canvas.toDataURL('image/jpeg', 0.78); // 改变画质
    this.toFile(data, fileObj);
  }

  @Emit('getImg')
  toFile(data: string, fileObj: File) { // base64转文件
    const arr = data.split(',');
    const bstr = atob(arr[1]); // 解码base64
    let n = bstr.length;
    const u8arr = new Uint8Array(n);
    while (n > 0) {
      u8arr[n] = bstr.charCodeAt(n);
      n -= 1;
    }
    const newFile = new File([u8arr], fileObj.name, { type: fileObj.type });
    console.log(`压缩后---${(newFile.size / 1024).toFixed(2)}KB`);
    return {
      newFile,
      data
    };
  }
}
</script>

<style scoped lang="scss">
.upload-box{
  width: auto;
  display: inline-block;
}
#upImg{
  display: none;
}
</style>
