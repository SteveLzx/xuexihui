<!--
在需要下拉刷新或者上拉加载的容器外面用LoadRefresh包裹，父级需要设置高度100%
1.下拉刷新
属性: @pull-callback="pullCallback" //下拉刷新回调方法
属性: fullFlag="false" // 禁用下拉刷新，仅使用上拉加载,默认开启
属性: ref="loadRefresh" // 组件名
方法: this.$ref.loadRefresh.pullSuccess() // 下拉刷新请求接口成功后调用组件方法通知组件更新状态

2.上拉加载
属性: @load-callback="loadCallback" //下拉刷新回调方法
属性: loadFlag="false" // 禁用上拉加载，仅使用下拉刷新,默认开启
属性: ref="loadRefresh" // 组件名
// 上拉加载请求接口成功后调用组件方法通知组件更新状态
   如果数据已加载完毕则需要传参数true
方法: this.$ref.loadRefresh.loadSuccess()
-->

<template>
  <div id="load-box"
       @scroll.passive="onScroll"
       @touchstart="touchStart"
       @touchmove="touchMove"
       @touchend="touchEnd"
       ref="loadBox"
  >
    <p class="pull"
       :style="`height: ${pullTop}px;transition: ${springFlag ? 0.4 : 0}s;`">
      <i class="xxh-loading" v-if="state === 2"></i>
      <span>{{tooltip[state]}}</span>
    </p>
    <slot></slot>
    <p class="pull" style="height: 1rem;" v-if="showLoading && !loadDone">
      加载中
    </p>
    <p class="pull" style="height: 1rem;" v-if="allLoad">
      没有更多数据了
    </p>
  </div>
</template>

<script lang="ts">
import {
  Vue,
  Component,
  Emit,
  Ref
} from 'vue-property-decorator';

@Component
export default class LoadRefresh extends Vue {
  private pageX = 0;

  private pageY = 0;

  private pullTop = 0;

  private tooltip = ['下拉刷新...', '松开刷新...', '加载中...'];

  private state = 0; // 0: 初始状态 1: 拉到极限 2: 松开触发回调

  private springFlag = false;

  private pullFlag = false; // 下拉刷新 || 上拉加载

  private scrollTop = 0; // 页面滚动的高度

  private showLoading = false; // 展示上拉加载loading图标

  private loadDone = true; // 上拉加载是否完毕

  private allLoad = false; // 是否已全部加载

  @Ref() readonly loadBox: HTMLDivElement;

  touchStart(event: TouchEvent) { // 开始拖动
    // 记录拖动点
    this.springFlag = false;
    this.pageY = event.targetTouches[0].pageY;
    this.scrollTop = this.loadBox.scrollTop;
  }

  touchMove(event: TouchEvent) { // 移动
    const { pageY } = event.targetTouches[0];
    if (pageY > this.pageY) { // 向下拉
      if (this.scrollTop !== 0 || (this.$attrs && this.$attrs.pullFlag === 'false')) { // 如果不是从最顶端往下拉则不处理
        return;
      }
      const y = pageY - this.pageY;
      this.pullTop = y >= 70 ? 70 : y; // 对应文字的高度
      this.state = y >= 70 ? 1 : 0; // 显示对应文字
      this.pullFlag = true;
    } else { // 向上滚动
      this.pullFlag = false;
    }
  }

  touchEnd() {
    if (!this.pullFlag) return; // 如果是上拉加载则不执行
    this.springFlag = true;
    if (this.pullTop === 70) { // 触发刷新
      this.pullCallback();
    } else { // 未拉到触发点则还原
      this.pullTop = 0;
    }
  }

  @Emit()
  pullCallback() {
    this.state = 2;
  }

  public pullSuccess() {
    const timer = setTimeout(() => {
      this.state = 0;
      clearTimeout(timer);
    }, 300);
    this.pullTop = 0;
  }

  onScroll() {
    if (this.$attrs && this.$attrs.loadFlag === 'false') return; // 禁用了上拉加载
    const { scrollHeight, clientHeight, scrollTop } = this.loadBox;
    // 不够一屏则无加载
    if (scrollHeight <= clientHeight) return;
    if (scrollHeight - clientHeight - scrollTop < 100) {
      if (!this.showLoading && this.loadDone && !this.allLoad) {
        this.loadCallback();
        this.showLoading = true;
        this.loadDone = false;
      }
    }
  }

  @Emit()
  loadCallback() {
    console.log('该加载了兄弟');
  }

  public loadSuccess(done = false, done2 = true, done3 = false) {
    this.showLoading = done;
    this.loadDone = done2;
    this.allLoad = done3;
  }
}
</script>

<style scoped lang="scss">
#load-box{
  height: 100%;
  overflow-y: scroll;
  overflow-x: hidden;
  // background: #fff;
}
.pull{
  text-align: center;
  font-size: 0.28rem;
  line-height: 1rem;
  overflow: hidden;
  span{
    color: $text2;
  }
}
.xxh-loading{
  width: 0.4rem;
  height: 0.4rem;
  margin-right: 0.15rem;
  display: inline-block;
  animation: shyLoading .8s steps(12, end) infinite;
  background: url('../../assets/img/loading-2.png') no-repeat center center;
  background-size: 100% 100%;
  position: relative;
  top: 0.1rem;
}
@-webkit-keyframes shyLoading {
  0% {
    transform: rotate3d(0, 0, 1, 0deg);
  }

  100% {
    transform: rotate3d(0, 0, 1, 360deg);
  }
}
@keyframes shyLoading {
  0% {
    transform: rotate3d(0, 0, 1, 0deg);
  }

  100% {
    transform: rotate3d(0, 0, 1, 360deg);
  }
}
</style>
