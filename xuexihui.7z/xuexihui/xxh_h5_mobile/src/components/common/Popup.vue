<!--
<Popup
  v-model="showPopup"
  :id='popupId'
  :title="'标题'"
  :text="'内容'"
  :cancel-text="'取消'"
  :confirm-text="'确认'"
  :cancel-color="'#000000'"
  :confirm-color="'#2CC07C'"
  @cancelCallBack="cancelCallBack"
  @confirmCallBack="confirmCallBack"
></Popup>
id:每个弹窗的标识，按钮返回函数要用
title: 标题
text: 弹窗文案
cancel-text: 左边按钮文案
confirm-color: 右边按钮文案
cancel-color: 左边按钮颜色
confirm-color: 右边按钮颜色
cancelCallBack：左边按钮回调函数
confirmCallBack：右边按钮回调函数
-->
<template>
  <div class="full-screen-bg" v-if="value">
    <div class="popup-box">
      <h2 class="title" v-if="title">{{title}}</h2>
      <div :class="['content', {'have-title-content': title}]" v-html="text"></div>
      <div class="operation">
        <div
            v-if="cancelText"
            class="cancel"
            :style="{'color': cancelColor}"
            @click.stop="onCancel"
        >{{cancelText}}</div>
        <div
            class="confirm"
            :style="{'color': confirmColor}"
            @click.stop="onConfirm"
        >{{confirmText}}</div>
      </div>
    </div>
  </div>
</template>
<script lang="ts">
import {
  Component,
  Prop,
  Model,
  Emit,
  Vue
} from 'vue-property-decorator';

@Component
export default class Popup extends Vue {
  @Model('value', { type: Boolean }) value!: boolean;

  @Prop({
    type: Number,
    required: true,
    default: 1
  }) id !: number;

  @Prop({
    type: String,
    required: false,
    default: ''
  }) title !: string;

  @Prop({
    type: String,
    required: false,
    default: ''
  }) text !: string;

  @Prop({
    type: String,
    required: false,
    default: ''
  }) cancelText !: string;

  @Prop({
    type: String,
    required: false,
    default: ''
  }) confirmText !: string;

  @Prop({
    type: String,
    required: false,
    default: ''
  }) cancelColor !: string;

  @Prop({
    type: String,
    required: false,
    default: ''
  }) confirmColor !: string;

  @Emit('cancelCallBack')
  private cancelCallBack(data: number): number {
    return data;
  }

  private onCancel(): void {
    this.cancelCallBack(this.$props.id);
  }

  @Emit('confirmCallBack')
  private confirmCallBack(data: number): number {
    return data;
  }

  private onConfirm(): void {
    this.confirmCallBack(this.$props.id);
  }
}
</script>
<style lang="scss" scoped>
.popup-box{
  position: absolute;
  left: 50%;
  top: 50%;
  transform: translate3d(-50%, -50%, 0);
  width: 6.40rem;
  border-radius: 0.24rem;
  background-color: #ffffff;
}
.title{
  padding-top: 0.64rem;
  height: 0.48rem;
  color: #353535;
  font-size: 0.34rem;
  text-align: center;
  font-weight: 500;
  font-family: PingFangSC-Medium;
}
.content{
  display: flex;
  align-items: center;
  justify-content: center;
  box-sizing: border-box;
  min-height: 2.08rem;
  padding: 0 0.48rem;
  color:#353535;
  font-size: 0.34rem;
  text-align: center;
  font-family: PingFangSC-Regular;
}
.have-title-content{
  min-height: auto;
  padding: 0.32rem 0.48rem 0.64rem 0.48rem;
}
.operation{
  border-top: 1px solid $line;
  display: flex;
  height: 1.1rem;
  line-height: 1.1rem;
  text-align: center;
  >div{
    flex: 1;
    font-size: 0.34rem;
    height: 1.1rem;
    font-family: PingFangSC-Regular;
  }
}
.cancel{
  border-right: 1px solid $line;
}
.confirm{
  color: $first;
}
</style>
