import Vue from 'vue';
import Toast from './Index.vue';

type ToastOption = {
    text?: string;
    timeout?: number;
}
const ToastBox = Vue.extend(Toast);
const instance = new ToastBox().$mount();

let timer: any = null;
const toast = (options: ToastOption | string) => {
  let text = '服务忙,请稍后重试';
  let timeout = 3;
  if (options && typeof options === 'object') {
    text = options.text || '服务忙,请稍后重试';
    timeout = options.timeout || 3;
  }
  if (options && typeof options === 'string') text = options;
  instance.$data.text = text;
  instance.$data.visible = true;
  document.body.appendChild(instance.$el);
  // 先清除上一个定时器
  clearTimeout(timer);
  timer = setTimeout(() => {
    if (instance && instance.$el) {
      instance.$data.visible = false;
      document.body.removeChild(instance.$el);
    }
  }, timeout * 1000);
};
export default toast;
