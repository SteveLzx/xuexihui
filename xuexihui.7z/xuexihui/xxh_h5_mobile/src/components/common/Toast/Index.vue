/*
//显示toast
this.$xxhToast();

//显示带字符串toast
this.$xxhToast({text:"加载中"});

//可以直接传字符串
this.$xxhToast("加载中...");

//toast延时关闭, 默认3秒
this.$xxhToast({timeout: 30});

// 新增遮罩层点击隐藏

*/
<template>
  <div class="full-screen-bg2" @touchstart="visible = false" v-show="visible">
    <div class="toast-box" @click.stop="">
      {{text}}
    </div>
  </div>
</template>
<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';

@Component
export default class Toast extends Vue {
  public text = '';

  public visible = false;
}
</script>
<style lang="scss" scoped>
.toast-box{
  text-align: center;
  position: fixed;
  left: 50%;
  top: 50%;
  display: flex;
  justify-content: center;
  align-items: center;
  transform: translate(-50%,-50%);
  min-width: 2.1rem;
  max-width: 3.6rem;
  line-height: .42rem;
  color: #fff;
  padding: .29rem .3rem;
  box-sizing: border-box;
  background-color: rgba(0, 0, 0, 0.7);
  border-radius: 0.1rem;
  font-size: .3rem;
}
</style>
