module.exports = {
  css: {
    loaderOptions: {
      sass: { // 配置每个组件使用全局scss变量
        prependData: `
          @import "@/assets/css/common.scss";
        `
      }
    }
  }
};
